from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

import json
import numpy as np
import pandas as pd

ID_COL = "ipatient"


def _json_safe(x: Any) -> Any:
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        val = float(x)
        return None if np.isnan(val) or np.isinf(val) else val
    if isinstance(x, (pd.Timestamp,)):
        return x.isoformat()
    if isinstance(x, bool):
        return bool(x)
    return x


def read_csv_or_excel(path: str | Path, sheet_name: Optional[str] = None) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(path, sheet_name=sheet_name or 0)
    return pd.read_csv(path)


def load_optional_json(path: str | Path | None) -> Dict[str, Any]:
    if path is None:
        return {}
    path = Path(path)
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _find_prob_column(df: pd.DataFrame) -> str:
    candidates = ["prob", "prob_positive", "patient_probability", "predicted_probability"]
    for c in candidates:
        if c in df.columns:
            return c
    prob_cols = [c for c in df.columns if str(c).startswith("prob_")]
    if prob_cols:
        return prob_cols[0]
    raise ValueError("找不到影像預測機率欄位。可接受 prob、prob_positive 或 prob_*。")


def case_json_from_image_predictions(pred_df: pd.DataFrame, patient_id: str, metrics_summary: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    metrics_summary = metrics_summary or {}
    if ID_COL not in pred_df.columns:
        raise ValueError("影像預測表需要 ipatient 欄位。")
    pred_df = pred_df.copy()
    pred_df[ID_COL] = pred_df[ID_COL].astype(str)
    sub = pred_df[pred_df[ID_COL] == str(patient_id)]
    if sub.empty:
        raise ValueError(f"找不到 patient_id={patient_id}")
    row = sub.iloc[0]
    prob_col = _find_prob_column(pred_df)
    prob = float(row[prob_col])
    threshold = float(row.get("threshold", 0.5)) if "threshold" in row.index and not pd.isna(row.get("threshold")) else 0.5
    risk_group = "High" if prob >= threshold else "Low"
    if "pred_patient" in row.index:
        pred_label = int(row["pred_patient"])
    elif "y_pred" in row.index:
        pred_label = int(row["y_pred"])
    else:
        pred_label = int(prob >= threshold)

    model_perf: Dict[str, Any] = {}
    for key in ["patient_level_oof", "image_level_oof", "patient_level_cv", "image_level_cv"]:
        if key in metrics_summary:
            model_perf[key] = metrics_summary[key]
    for key in ["model_name", "aug_mode", "task", "cv_type", "n_total_images", "n_total_patients"]:
        if key in metrics_summary:
            model_perf[key] = metrics_summary[key]

    return {
        "schema_version": "1.1",
        "case_type": "image_classification_result",
        "patient": {
            "patient_id": str(patient_id),
            "n_images": _json_safe(row.get("n_images")),
            "available_prediction_row": {str(c): _json_safe(row[c]) for c in row.index},
        },
        "prediction": {
            "model_type": "image_classification_result_table",
            "model_name": str(row.get("model_name", metrics_summary.get("model_name", "Panoramic image model"))),
            "target_event": metrics_summary.get("task", "ORN image task"),
            "predicted_probability": prob,
            "predicted_label": pred_label,
            "risk_group": risk_group,
            "thresholds": {
                "positive_threshold": threshold,
                "threshold_basis": "from image pipeline validation threshold if available; otherwise 0.5",
            },
            "interpretation_note": "此結果來自影像 pipeline 已輸出的 patient-level prediction table；介面未重新訓練影像模型。",
        },
        "model_performance": model_perf,
        "explanation": {
            "method": "image pipeline patient-level prediction result",
            "top_positive_factors": [
                {
                    "feature": "panoramic_xray_image_features",
                    "display_name": "Panoramic X-ray image-derived representation",
                    "value": prob,
                    "direction": "increase_risk" if prob >= threshold else "decrease_risk",
                    "plain_language": "影像模型根據 panoramic X-ray 的深度特徵輸出此病人的影像層級或病人層級風險分數；此結果不是人工放射學診斷。",
                }
            ],
            "top_negative_factors": [],
            "missing_or_uncertain_items": [
                "若要對全新病人即時推論，需要另行載入已訓練的影像模型權重與 preprocessing metadata。"
            ],
        },
        "llm_guardrails": {
            "allowed_tasks": ["Explain the image model result table.", "State limitations of image-only prediction."],
            "forbidden_tasks": ["Do not invent image lesions.", "Do not diagnose ORN.", "Do not alter the probability."],
            "required_disclaimer": "本系統為影像模型風險分層輔助工具，不取代放射科或臨床醫師判讀。",
        },
    }
