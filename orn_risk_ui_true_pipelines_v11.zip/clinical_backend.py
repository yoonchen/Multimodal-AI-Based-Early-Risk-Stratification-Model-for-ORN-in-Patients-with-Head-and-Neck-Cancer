from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.calibration import CalibratedClassifierCV
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

ID_COL = "ipatient"
TARGET_COL = "ORN_label"
DROP_FOR_MODEL = ["orn_diagnosis_date", "censor_date", "reference_date_for_model"]
DEFAULT_EXCLUDE = ["mandible_resection_any", "maxilla_resection_any"]

EXPECTED_CATEGORICAL = [
    "性別",
    "Tumor location",
    "T_analyze",
    "N_analyze",
    "M_analyze",
    "吸菸史",
    "喝酒史",
    "嚼檳榔史",
    "tooth_extraction_worst",
    "mandible_resection_worst",
    "maxilla_resection_worst",
    "reconstruction_max",
]

FEATURE_DISPLAY = {
    "年齡": "Age",
    "性別": "Sex",
    "ECOG": "ECOG performance status",
    "Tumor location": "Tumor location",
    "T_analyze": "T stage",
    "N_analyze": "N stage",
    "M_analyze": "M stage",
    "吸菸史": "Smoking history",
    "喝酒史": "Alcohol history",
    "嚼檳榔史": "Betel nut history",
    "是否進行手術": "Surgery history",
    "tooth_extraction_count": "Tooth extraction count",
    "tooth_extraction_any": "Tooth extraction history",
    "tooth_extraction_ge3_any": "Tooth extraction ≥3",
    "tooth_extraction_worst": "Tooth extraction severity",
    "neck_dissection_pre_orn_any": "Neck dissection before ORN/censoring",
    "neck_dissection_pre_orn_count": "Neck dissection count",
    "mandible_resection_worst": "Mandible resection severity",
    "mandible_resection_count": "Mandible resection count",
    "mandible_segmental_any": "Segmental mandible resection",
    "mandible_marginal_any": "Marginal mandible resection",
    "maxilla_resection_worst": "Maxilla resection severity",
    "maxilla_resection_count": "Maxilla resection count",
    "maxilla_partial_any": "Partial maxilla resection",
    "maxilla_total_any": "Total maxilla resection",
    "reconstruction_any": "Reconstruction history",
    "reconstruction_count": "Reconstruction count",
    "reconstruction_max": "Reconstruction severity",
    "has_L": "Low-dose RT field indicator",
    "has_M": "Mid-dose RT field indicator",
    "CTV_H_dose_max": "High-dose CTV maximum dose",
    "CTV_M_dose_max": "Mid-dose CTV maximum dose",
    "CTV_L_dose_max": "Low-dose CTV maximum dose",
    "DM": "Diabetes mellitus",
    "HTN": "Hypertension",
    "ESRD": "End-stage renal disease",
    "Osteoporosis": "Osteoporosis",
}

PLAIN_LANGUAGE = {
    "ECOG": "ECOG 較高通常代表病人整體功能狀態較差，模型將其視為可能提高治療後併發症風險的訊號。",
    "mandible_resection_worst": "下顎骨切除程度較高，可能反映局部組織受損程度較大，因此模型判斷風險較高。",
    "mandible_resection_count": "下顎骨相關手術次數較多，可能代表局部治療負擔較重，因此模型判斷風險較高。",
    "tooth_extraction_count": "拔牙次數較多可能與局部骨癒合壓力或後續 ORN 風險增加有關。",
    "tooth_extraction_any": "有拔牙紀錄可能代表局部骨組織曾受額外處置，模型將其視為風險相關訊號。",
    "Tumor location": "腫瘤位置會影響受照射區域與局部組織風險，因此可能改變 ORN 風險。",
    "CTV_H_dose_max": "較高的高劑量放療區最大劑量可能代表骨組織接受較高治療負擔，模型可能將其視為風險訊號。",
    "CTV_M_dose_max": "中劑量區放療劑量可能反映治療暴露範圍與強度，模型可能將其視為風險相關訊號。",
    "CTV_L_dose_max": "低劑量區放療劑量在此案例中對模型風險判斷有一定影響，但需搭配其他臨床因素判讀。",
    "reconstruction_max": "重建方式較複雜時，可能代表手術範圍或組織缺損較大，因此模型可能判斷風險較高。",
    "年齡": "年齡可能反映基礎修復能力與共病負擔，模型會將其納入整體風險判斷。",
}


def safe_strip_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    return out


def read_table(path: str | Path, sheet_name: Optional[str] = None) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() in [".xlsx", ".xls"]:
        return safe_strip_columns(pd.read_excel(path, sheet_name=sheet_name or 0))
    if path.suffix.lower() == ".csv":
        return safe_strip_columns(pd.read_csv(path))
    raise ValueError(f"Unsupported file type: {path.suffix}")


def infer_feature_types(X: pd.DataFrame) -> Tuple[List[str], List[str]]:
    categorical_cols: List[str] = []
    numeric_cols: List[str] = []
    for c in X.columns:
        if c in EXPECTED_CATEGORICAL:
            categorical_cols.append(c)
        elif pd.api.types.is_numeric_dtype(X[c]):
            numeric_cols.append(c)
        else:
            categorical_cols.append(c)
    return numeric_cols, categorical_cols


def split_xy(
    df: pd.DataFrame,
    exclude_cols: Optional[List[str]] = None,
    target_col: str = TARGET_COL,
    id_col: str = ID_COL,
) -> Tuple[pd.DataFrame, pd.Series, pd.Series]:
    exclude_cols = exclude_cols or DEFAULT_EXCLUDE
    if target_col not in df.columns:
        raise ValueError(f"找不到目標欄位 {target_col}。")
    if id_col not in df.columns:
        raise ValueError(f"找不到病人 ID 欄位 {id_col}。")

    data = df.dropna(subset=[target_col]).copy()
    y = pd.to_numeric(data[target_col], errors="coerce")
    keep = y.notna()
    data = data.loc[keep].copy()
    y = y.loc[keep].astype(int)

    drop_cols = [id_col, target_col]
    drop_cols += [c for c in DROP_FOR_MODEL if c in data.columns]
    drop_cols += [c for c in exclude_cols if c in data.columns]
    X = data.drop(columns=drop_cols, errors="ignore")
    patient_ids = data[id_col].astype(str)
    return X, y, patient_ids


def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    numeric_cols, categorical_cols = infer_feature_types(X)
    num_pipe = Pipeline([("imputer", SimpleImputer(strategy="median"))])
    cat_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer([
        ("num", num_pipe, numeric_cols),
        ("cat", cat_pipe, categorical_cols),
    ])


def make_calibrated_classifier(estimator: Pipeline, method: str, cv) -> CalibratedClassifierCV:
    try:
        return CalibratedClassifierCV(estimator=estimator, method=method, cv=cv)
    except TypeError:
        return CalibratedClassifierCV(base_estimator=estimator, method=method, cv=cv)


def compute_ece(y_true: np.ndarray, y_prob: np.ndarray, n_bins: int = 10) -> float:
    bins = np.linspace(0, 1, n_bins + 1)
    bin_ids = np.digitize(y_prob, bins, right=True) - 1
    bin_ids = np.clip(bin_ids, 0, n_bins - 1)
    ece = 0.0
    for i in range(n_bins):
        mask = bin_ids == i
        if np.sum(mask) == 0:
            continue
        ece += abs(float(np.mean(y_prob[mask])) - float(np.mean(y_true[mask]))) * (np.sum(mask) / len(y_prob))
    return float(ece)


def choose_threshold(y_true: np.ndarray, y_prob: np.ndarray, min_sensitivity: float = 0.80) -> Dict[str, Any]:
    thresholds = np.unique(np.round(y_prob, 6))
    thresholds = np.sort(np.unique(np.concatenate(([0.0], thresholds, [1.0]))))
    rows = []
    for t in thresholds:
        pred = (y_prob >= t).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
        sens = tp / (tp + fn) if (tp + fn) else np.nan
        spec = tn / (tn + fp) if (tn + fp) else np.nan
        f1 = f1_score(y_true, pred, zero_division=0)
        rows.append({"threshold": float(t), "sensitivity": float(sens), "specificity": float(spec), "f1": float(f1)})
    df = pd.DataFrame(rows)
    feasible = df[df["sensitivity"] >= min_sensitivity].copy()
    if len(feasible):
        best = feasible.sort_values(["specificity", "f1", "threshold"], ascending=[False, False, True]).iloc[0].to_dict()
        best["selection_rule"] = f"max specificity under sensitivity >= {min_sensitivity:.2f}"
    else:
        best = df.sort_values(["f1", "specificity", "threshold"], ascending=[False, False, True]).iloc[0].to_dict()
        best["selection_rule"] = "fallback max F1"
    best["threshold_scan"] = rows
    return best


def normalize_classification_thresholds(thresholds: Dict[str, Any]) -> Dict[str, Any]:
    """Separate display risk tiers from the sensitivity-optimized positive threshold.

    Older bundles stored the sensitivity-optimized threshold in ``intermediate_to_high``.
    That made cases such as 48% appear as "High risk" when the screening threshold was
    around 23%. For the UI, we keep that value as ``classification_positive_threshold``
    but use fixed display tiers for Low / Intermediate / High.
    """
    t = dict(thresholds or {})
    raw_mid_high = t.get("intermediate_to_high")
    legacy_screening_threshold = None
    try:
        if raw_mid_high is not None and float(raw_mid_high) < 0.50 and "classification_positive_threshold" not in t and "positive_threshold" not in t:
            legacy_screening_threshold = float(raw_mid_high)
    except Exception:
        legacy_screening_threshold = None

    if legacy_screening_threshold is not None:
        t["classification_positive_threshold"] = legacy_screening_threshold
        t["positive_threshold"] = legacy_screening_threshold
        t["low_to_intermediate"] = 0.33
        t["intermediate_to_high"] = 0.66
        t["risk_group_basis"] = "legacy bundle normalized: display tiers Low < 0.33, Intermediate 0.33–0.66, High ≥ 0.66; original low threshold is treated as classification-positive threshold"
    else:
        t.setdefault("low_to_intermediate", 0.33)
        t.setdefault("intermediate_to_high", 0.66)
        if "classification_positive_threshold" not in t and "positive_threshold" in t:
            t["classification_positive_threshold"] = t["positive_threshold"]
        t.setdefault("risk_group_basis", "display tiers: Low < 0.33, Intermediate 0.33–0.66, High ≥ 0.66")
    return t


def risk_group_from_probability(prob: float, thresholds: Dict[str, Any]) -> str:
    t = normalize_classification_thresholds(thresholds)
    low_mid = float(t.get("low_to_intermediate", 0.33))
    mid_high = float(t.get("intermediate_to_high", 0.66))
    if prob >= mid_high:
        return "High"
    if prob >= low_mid:
        return "Intermediate"
    return "Low"


def probability_metrics(y_true: np.ndarray, y_prob: np.ndarray, threshold: float) -> Dict[str, Any]:
    pred = (y_prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        "roc_auc": float(roc_auc_score(y_true, y_prob)) if len(np.unique(y_true)) > 1 else float("nan"),
        "accuracy": float(accuracy_score(y_true, pred)),
        "sensitivity": float(recall_score(y_true, pred, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if (tn + fp) else float("nan"),
        "precision_ppv": float(precision_score(y_true, pred, zero_division=0)),
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "brier_score": float(brier_score_loss(y_true, y_prob)),
        "ece": float(compute_ece(y_true, y_prob)),
        "threshold": float(threshold),
        "TP": int(tp), "FP": int(fp), "TN": int(tn), "FN": int(fn),
    }


def baseline_values_from_X(X: pd.DataFrame) -> Dict[str, Any]:
    baseline: Dict[str, Any] = {}
    numeric_cols, categorical_cols = infer_feature_types(X)
    for c in numeric_cols:
        baseline[c] = float(pd.to_numeric(X[c], errors="coerce").median())
    for c in categorical_cols:
        s = X[c].dropna()
        baseline[c] = s.mode().iloc[0] if len(s.mode()) else None
    return baseline


def train_clinical_bundle(
    data_path: str | Path,
    sheet_name: str = "model_full_pre_orn",
    output_path: str | Path = "clinical_model_bundle.joblib",
    min_sensitivity: float = 0.80,
    calibration_method: str = "isotonic",
    random_state: int = 42,
) -> Dict[str, Any]:
    df = read_table(data_path, sheet_name=sheet_name)
    X, y, patient_ids = split_xy(df)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)

    base_pipe = Pipeline([
        ("preprocess", build_preprocessor(X)),
        ("model", RandomForestClassifier(
            n_estimators=500,
            max_depth=4,
            min_samples_split=8,
            min_samples_leaf=4,
            class_weight="balanced",
            random_state=random_state,
        )),
    ])
    calibrated_for_oof = make_calibrated_classifier(clone(base_pipe), method=calibration_method, cv=3)
    oof_prob = cross_val_predict(calibrated_for_oof, X, y, cv=cv, method="predict_proba")[:, 1]
    threshold_info = choose_threshold(y.to_numpy(), oof_prob, min_sensitivity=min_sensitivity)
    # The threshold selected for classification is optimized for screening sensitivity.
    # It should not be directly interpreted as the boundary for the visual "High risk" tier.
    positive_thr = float(threshold_info["threshold"])
    display_low_mid = 0.33
    display_mid_high = 0.66
    thresholds = {
        "low_to_intermediate": float(display_low_mid),
        "intermediate_to_high": float(display_mid_high),
        "classification_positive_threshold": float(positive_thr),
        "positive_threshold": float(positive_thr),
        "threshold_basis": threshold_info["selection_rule"],
        "risk_group_basis": "display tiers: Low < 0.33, Intermediate 0.33–0.66, High ≥ 0.66; classification-positive threshold is reported separately",
    }
    performance = probability_metrics(y.to_numpy(), oof_prob, threshold=positive_thr)

    final_model = make_calibrated_classifier(clone(base_pipe), method=calibration_method, cv=cv)
    final_model.fit(X, y)
    train_prob = final_model.predict_proba(X)[:, 1]
    pred_df = pd.DataFrame({
        ID_COL: patient_ids.to_numpy(),
        "y_true": y.to_numpy(),
        "predicted_probability": train_prob,
        "risk_group": [risk_group_from_probability(float(p), thresholds) for p in train_prob],
    })

    bundle: Dict[str, Any] = {
        "bundle_type": "clinical_classification",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "source_pipeline": "pipeline_final_beeswarm.py compatible deploy bundle",
        "model_name": "Calibrated RandomForest clinical classification model",
        "model": final_model,
        "feature_columns": list(X.columns),
        "baseline_values": baseline_values_from_X(X),
        "thresholds": thresholds,
        "threshold_scan": threshold_info.get("threshold_scan", []),
        "model_performance": performance,
        "patient_source_table": pd.concat([patient_ids.rename(ID_COL), X.reset_index(drop=True)], axis=1),
        "patient_predictions": pred_df,
        "notes": [
            "This model outputs calibrated binary ORN probability.",
            "LLM should only explain the model output JSON and must not recalculate risk.",
        ],
    }
    joblib.dump(bundle, output_path)
    return bundle


def load_bundle(path: str | Path) -> Dict[str, Any]:
    return joblib.load(path)


def _predict_one(bundle: Dict[str, Any], row: pd.Series) -> float:
    X_one = pd.DataFrame([row[bundle["feature_columns"]].to_dict()])
    return float(bundle["model"].predict_proba(X_one)[:, 1][0])


def _local_factor_effects(bundle: Dict[str, Any], row: pd.Series, top_k: int = 6) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    feature_cols = bundle["feature_columns"]
    prob_current = _predict_one(bundle, row)
    baseline_values = bundle.get("baseline_values", {})
    effects: List[Dict[str, Any]] = []
    for feat in feature_cols:
        if feat not in row.index:
            continue
        baseline_value = baseline_values.get(feat)
        if baseline_value is None:
            continue
        perturbed = row.copy()
        perturbed[feat] = baseline_value
        try:
            prob_without_patient_value = _predict_one(bundle, perturbed)
            delta = prob_current - prob_without_patient_value
        except Exception:
            continue
        if abs(delta) < 1e-6:
            continue
        effects.append({
            "feature": feat,
            "display_name": FEATURE_DISPLAY.get(feat, feat),
            "value": _json_safe(row.get(feat)),
            "baseline_value": _json_safe(baseline_value),
            "effect_vs_baseline": float(delta),
            "direction": "increase_risk" if delta > 0 else "decrease_risk",
            "plain_language": PLAIN_LANGUAGE.get(feat, "此變項相較於資料集基準值，對模型風險分數有可觀影響。"),
        })
    positive = sorted([e for e in effects if e["effect_vs_baseline"] > 0], key=lambda x: abs(x["effect_vs_baseline"]), reverse=True)[:top_k]
    negative = sorted([e for e in effects if e["effect_vs_baseline"] < 0], key=lambda x: abs(x["effect_vs_baseline"]), reverse=True)[:top_k]
    return positive, negative


def _json_safe(x: Any) -> Any:
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        val = float(x)
        return None if np.isnan(val) or np.isinf(val) else val
    if isinstance(x, (pd.Timestamp,)):
        return x.isoformat()
    if isinstance(x, bool):
        return bool(x)
    return x


def case_json_from_clinical_patient(bundle: Dict[str, Any], patient_id: str) -> Dict[str, Any]:
    source = bundle["patient_source_table"].copy()
    source[ID_COL] = source[ID_COL].astype(str)
    sub = source[source[ID_COL] == str(patient_id)]
    if sub.empty:
        raise ValueError(f"找不到 patient_id={patient_id}")
    row = sub.iloc[0]
    prob = _predict_one(bundle, row)
    thresholds = normalize_classification_thresholds(bundle.get("thresholds", {}))
    risk_group = risk_group_from_probability(prob, thresholds)
    pos, neg = _local_factor_effects(bundle, row)

    patient_payload = {
        "patient_id": str(patient_id),
        "available_features": {c: _json_safe(row[c]) for c in bundle["feature_columns"] if c in row.index},
    }
    return {
        "schema_version": "1.1",
        "case_type": "clinical_classification",
        "patient": patient_payload,
        "prediction": {
            "model_type": "binary_classification",
            "model_name": bundle.get("model_name", "Clinical classification model"),
            "target_event": "ORN occurrence",
            "predicted_probability": float(prob),
            "risk_group": risk_group,
            "thresholds": thresholds,
            "interpretation_note": "此分數是分類模型輸出的校準後 ORN 風險機率；風險分層採固定顯示門檻，模型陽性門檻另列。",
        },
        "model_performance": bundle.get("model_performance", {}),
        "explanation": {
            "method": "local feature replacement against training-set baseline",
            "top_positive_factors": pos,
            "top_negative_factors": neg,
            "missing_or_uncertain_items": [],
        },
        "llm_guardrails": {
            "allowed_tasks": [
                "Explain the already computed risk score.",
                "Summarize the listed model-derived factors.",
                "State model limitations and clinical caution.",
            ],
            "forbidden_tasks": [
                "Do not recalculate or alter predicted_probability.",
                "Do not diagnose ORN.",
                "Do not provide treatment instructions.",
                "Do not introduce risk factors absent from JSON.",
            ],
            "required_disclaimer": "本系統為 ORN 風險分層輔助工具，不取代臨床診斷或醫師判讀。",
        },
    }
