from __future__ import annotations

import argparse
from pathlib import Path

from clinical_backend import train_clinical_bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Train clinical ORN classification deploy bundle.")
    parser.add_argument("--data_path", type=str, default="data_v3.1.xlsx")
    parser.add_argument("--sheet_name", type=str, default="model_full_pre_orn")
    parser.add_argument("--output_path", type=str, default="clinical_model_bundle.joblib")
    parser.add_argument("--min_sensitivity", type=float, default=0.80)
    parser.add_argument("--calibration_method", type=str, default="isotonic", choices=["isotonic", "sigmoid"])
    args = parser.parse_args()

    bundle = train_clinical_bundle(
        data_path=args.data_path,
        sheet_name=args.sheet_name,
        output_path=args.output_path,
        min_sensitivity=args.min_sensitivity,
        calibration_method=args.calibration_method,
    )
    print("Clinical model bundle saved:", Path(args.output_path).resolve())
    print("Model performance:")
    for k, v in bundle["model_performance"].items():
        if k != "threshold_scan":
            print(f"  {k}: {v}")
    print("Thresholds:", bundle["thresholds"])


if __name__ == "__main__":
    main()
