from __future__ import annotations

import argparse
from pathlib import Path

from survival_backend import train_survival_bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Train multimodal Cox survival deploy bundle.")
    parser.add_argument("--data_path", type=str, default="data_v3.1.xlsx")
    parser.add_argument("--time_sheet", type=str, default="ALL")
    parser.add_argument("--feature_sheet", type=str, default="model_full_pre_orn")
    parser.add_argument("--image_excel", type=str, default="image_data.xlsx")
    parser.add_argument("--image_sheet", type=str, default="image_master")
    parser.add_argument("--image_root", type=str, required=True)
    parser.add_argument("--output_dir", type=str, default="survival_bundle_outputs")
    parser.add_argument("--output_path", type=str, default="survival_model_bundle.joblib")
    parser.add_argument("--img_size", type=int, default=224)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--image_pooling", type=str, default="meanmax", choices=["mean", "max", "meanmax"])
    parser.add_argument("--image_pca_components", type=int, default=3)
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--no_pretrained", action="store_true")
    args = parser.parse_args()

    bundle = train_survival_bundle(
        data_path=args.data_path,
        time_sheet=args.time_sheet,
        feature_sheet=args.feature_sheet,
        image_excel=args.image_excel,
        image_sheet=args.image_sheet,
        image_root=args.image_root,
        output_dir=args.output_dir,
        output_path=args.output_path,
        img_size=args.img_size,
        batch_size=args.batch_size,
        image_pooling=args.image_pooling,
        image_pca_components=args.image_pca_components,
        pretrained=(not args.no_pretrained),
        cpu=args.cpu,
    )
    print("Survival model bundle saved:", Path(args.output_path).resolve())
    print("Clinical-only C-index:", bundle.get("clinical_only_cindex"))
    print("Multimodal C-index:", bundle.get("multimodal_cindex"))
    print("C-index improvement:", bundle.get("cindex_improvement"))
    print("Log-rank p:", bundle.get("logrank_p"))


if __name__ == "__main__":
    main()
