from __future__ import annotations

import json
import os
import re
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

import joblib
import numpy as np
import pandas as pd
import streamlit as st

from clinical_backend import load_bundle as load_clinical_bundle, case_json_from_clinical_patient, ID_COL as CLINICAL_ID
from survival_backend import load_bundle as load_survival_bundle, case_json_from_survival_patient
from image_results_backend import read_csv_or_excel, load_optional_json, case_json_from_image_predictions

APP_TITLE = "ORN 個人化風險分層與 LLM 輔助解釋介面"


# ============================================================
# JSON safety helpers
# ============================================================
def make_json_serializable(obj: Any) -> Any:
    """Recursively convert pandas / numpy scalar values to native JSON-safe Python types.

    Streamlit can display pandas/numpy values, but json.dumps cannot serialize
    numpy.bool_, numpy.integer, numpy.floating, NaN/Inf, Timestamp, etc.
    This helper is applied before rendering or downloading the case JSON.
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
            return None
        return obj
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        val = float(obj)
        return None if np.isnan(val) or np.isinf(val) else val
    if isinstance(obj, (pd.Timestamp,)):
        return None if pd.isna(obj) else obj.isoformat()
    if isinstance(obj, dict):
        return {str(k): make_json_serializable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [make_json_serializable(v) for v in obj]
    try:
        if pd.isna(obj):
            return None
    except Exception:
        pass
    return str(obj)


# ============================================================
# Styling
# ============================================================
def inject_css() -> None:
    st.markdown(
        """
        <style>
        .main .block-container {
            padding-top: 1.3rem;
            padding-bottom: 2rem;
            max-width: 1360px;
        }
        h1, h2, h3 { letter-spacing: -0.02em; }
        .hero {
            background: linear-gradient(135deg, #f8fbff 0%, #edf4ff 52%, #fff7ed 100%);
            border: 1px solid #e6eaf0;
            border-radius: 26px;
            padding: 24px 28px;
            margin-bottom: 18px;
            box-shadow: 0 14px 32px rgba(15, 23, 42, 0.06);
        }
        .hero-title {
            font-size: 32px;
            font-weight: 900;
            color: #101828;
            margin-bottom: 6px;
        }
        .hero-subtitle {
            font-size: 15px;
            color: #475467;
            line-height: 1.65;
        }
        .risk-card {
            border: 1px solid #e6eaf0;
            border-radius: 24px;
            padding: 22px;
            background: #ffffff;
            box-shadow: 0 10px 26px rgba(15, 23, 42, 0.06);
            min-height: 230px;
        }
        .small-label {
            color: #667085;
            font-size: 12px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .patient-id {
            font-size: 22px;
            color: #101828;
            font-weight: 850;
        }
        .risk-number {
            font-size: 54px;
            font-weight: 950;
            line-height: 1;
            color: #101828;
            margin-top: 8px;
            margin-bottom: 12px;
        }
        .risk-badge {
            display: inline-block;
            color: white;
            padding: 7px 14px;
            border-radius: 999px;
            font-weight: 850;
            font-size: 13px;
        }
        .note-box {
            border-left: 4px solid #2e90fa;
            background: #eff8ff;
            padding: 12px 14px;
            border-radius: 12px;
            color: #344054;
            font-size: 14px;
            margin: 10px 0;
        }
        .warn-box {
            border-left: 4px solid #f79009;
            background: #fffaeb;
            padding: 12px 14px;
            border-radius: 12px;
            color: #344054;
            font-size: 14px;
            margin: 10px 0;
        }
        .section-card {
            border: 1px solid #e6eaf0;
            border-radius: 20px;
            padding: 18px;
            background: #ffffff;
            box-shadow: 0 8px 20px rgba(15, 23, 42, 0.04);
            margin-bottom: 16px;
        }
        div[data-testid="metric-container"] {
            background: #ffffff;
            border: 1px solid #e6eaf0;
            padding: 14px 16px;
            border-radius: 18px;
            box-shadow: 0 8px 18px rgba(15, 23, 42, 0.04);
        }
        .stChatMessage { border-radius: 18px; }
        .chat-panel {
            border: 1px solid #e6eaf0;
            border-radius: 24px;
            background: #ffffff;
            padding: 16px 18px;
            box-shadow: 0 10px 26px rgba(15, 23, 42, 0.05);
            margin-bottom: 12px;
        }
        .quick-title {
            font-size: 13px;
            font-weight: 800;
            color: #475467;
            margin-bottom: 8px;
        }
        .threshold-box {
            border-left: 4px solid #7c3aed;
            background: #f5f3ff;
            padding: 12px 14px;
            border-radius: 12px;
            color: #344054;
            font-size: 14px;
            margin: 10px 0;
        }
        code { white-space: pre-wrap !important; }
        </style>
        """,
        unsafe_allow_html=True,
    )


# ============================================================
# Utilities
# ============================================================
def risk_badge_color(risk_group: str) -> str:
    s = str(risk_group).lower()
    if s == "high":
        return "#B42318"
    if s == "intermediate":
        return "#B54708"
    return "#027A48"


def risk_label_zh(risk_group: str) -> str:
    return {"High": "高風險", "Intermediate": "中風險", "Low": "低風險"}.get(str(risk_group), str(risk_group))


def get_classification_positive_status(case: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    pred = case.get("prediction", {})
    if pred.get("model_type") != "binary_classification":
        return None
    prob = pred.get("predicted_probability")
    thresholds = pred.get("thresholds", {})
    positive_thr = thresholds.get("classification_positive_threshold", thresholds.get("positive_threshold"))
    if positive_thr is None:
        legacy_thr = thresholds.get("intermediate_to_high")
        try:
            if legacy_thr is not None and float(legacy_thr) < 0.50 and "risk_group_basis" not in thresholds:
                positive_thr = legacy_thr
        except Exception:
            pass
    if prob is None or positive_thr is None:
        return None
    try:
        prob_f = float(prob)
        thr_f = float(positive_thr)
    except Exception:
        return None
    return {
        "probability": prob_f,
        "positive_threshold": thr_f,
        "is_model_positive": prob_f >= thr_f,
        "threshold_basis": thresholds.get("threshold_basis", "not provided"),
        "risk_group_basis": thresholds.get("risk_group_basis", "not provided"),
    }


def metric_fmt(x: Any, digits: int = 3) -> str:
    try:
        val = float(x)
        if pd.isna(val):
            return "NA"
        return f"{val:.{digits}f}"
    except Exception:
        return "NA" if x is None else str(x)


def flatten_numeric_metrics(obj: Any, prefix: str = "") -> Dict[str, Any]:
    """Flatten nested model_performance dictionaries and keep scalar values for display."""
    out: Dict[str, Any] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_numeric_metrics(v, key))
        return out
    if isinstance(obj, (list, tuple)):
        # Keep short numeric CI lists as a readable value, but do not explode every element.
        if len(obj) <= 4 and all(isinstance(x, (int, float, np.integer, np.floating)) or x is None for x in obj):
            out[prefix] = obj
        return out
    if isinstance(obj, (str, int, float, bool, np.integer, np.floating, np.bool_)) or obj is None:
        out[prefix] = obj
    return out


def metric_display_value(x: Any, digits: int = 3) -> str:
    if isinstance(x, list):
        vals = []
        for v in x:
            try:
                vals.append(f"{float(v):.{digits}f}")
            except Exception:
                vals.append(str(v))
        return "[" + ", ".join(vals) + "]"
    return metric_fmt(x, digits)


def format_metric_name(name: str) -> str:
    mapping = {
        "patient_level_oof.auroc": "Patient OOF AUROC",
        "patient_level_oof.f1": "Patient OOF F1",
        "patient_level_oof.sensitivity": "Patient Sensitivity",
        "patient_level_oof.specificity": "Patient Specificity",
        "image_level_oof.auroc": "Image OOF AUROC",
        "image_level_oof.f1": "Image OOF F1",
        "image_level_oof.sensitivity": "Image Sensitivity",
        "image_level_oof.specificity": "Image Specificity",
        "patient_level_cv.patient_level_auroc_mean": "Patient CV AUROC mean",
        "patient_level_cv.patient_level_auroc_std": "Patient CV AUROC std",
        "image_level_cv.image_level_auroc_mean": "Image CV AUROC mean",
        "image_level_cv.image_level_auroc_std": "Image CV AUROC std",
        "roc_auc": "ROC-AUC",
        "brier_score": "Brier score",
        "ece": "ECE",
        "sensitivity": "Sensitivity",
        "specificity": "Specificity",
        "multimodal_cindex": "Multimodal C-index",
        "clinical_only_cindex": "Clinical-only C-index",
        "cindex_improvement": "C-index improvement",
        "logrank_p_high_vs_low": "Log-rank p",
    }
    return mapping.get(name, name)


def build_reference_explanation(case: Dict[str, Any]) -> str:
    """Reference text used for BERTScore consistency checking.

    In the current prototype the assistant response is rule-based; when replacing it
    with a real LLM, this function can be kept as the reference template.
    """
    pred = case.get("prediction", {})
    exp = case.get("explanation", {})
    patient_id = case.get("patient", {}).get("patient_id", "NA")
    risk_group = pred.get("risk_group", "Unknown")
    parts = [f"病人 {patient_id} 的模型分層為 {risk_label_zh(risk_group)}。"]
    if case.get("case_type") == "multimodal_survival_cox":
        parts.append(f"Cox 相對風險分數為 {metric_fmt(pred.get('risk_score'))}，不是絕對發生機率。")
    else:
        try:
            parts.append(f"分類模型預測機率為 {float(pred.get('predicted_probability', 0)):.1%}。")
        except Exception:
            parts.append("分類模型預測機率未提供。")
    factors = exp.get("top_positive_factors", [])[:5]
    if factors:
        parts.append("主要模型因素包括：" + "；".join([str(f.get("display_name") or f.get("feature")) for f in factors]))
    parts.append(case.get("llm_guardrails", {}).get("required_disclaimer", "本系統為風險分層輔助工具，不取代臨床診斷或醫師判讀。"))
    return "\n".join(parts)


def _simple_char_f1(candidate: str, reference: str) -> Dict[str, Any]:
    cand_chars = [c for c in re.sub(r"\s+", "", candidate)]
    ref_chars = [c for c in re.sub(r"\s+", "", reference)]
    if not cand_chars or not ref_chars:
        return {"precision": None, "recall": None, "f1": None}
    from collections import Counter
    c1, c2 = Counter(cand_chars), Counter(ref_chars)
    overlap = sum((c1 & c2).values())
    precision = overlap / max(len(cand_chars), 1)
    recall = overlap / max(len(ref_chars), 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-12)
    return {"precision": float(precision), "recall": float(recall), "f1": float(f1)}


@st.cache_data(show_spinner=False)
def compute_bertscore_cached(candidate: str, reference: str) -> Dict[str, Any]:
    """Compute actual BERTScore when bert_score is installed; otherwise use a transparent fallback.

    The fallback is only for UI debugging. Thesis/report results should use actual
    BERTScore or expert review, not the fallback value.
    """
    try:
        from bert_score import score as bert_score_score  # type: ignore
        P, R, F1 = bert_score_score(
            [candidate],
            [reference],
            lang="zh",
            model_type="bert-base-chinese",
            verbose=False,
            rescale_with_baseline=False,
        )
        return {
            "method": "BERTScore bert-base-chinese",
            "precision": float(P[0]),
            "recall": float(R[0]),
            "f1": float(F1[0]),
            "reference": reference,
        }
    except Exception as e:
        vals = _simple_char_f1(candidate, reference)
        vals.update({
            "method": "fallback_char_overlap_not_official_BERTScore",
            "error": str(e)[:260],
            "reference": reference,
        })
        return vals


def load_json_default(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_uploaded_to_temp(uploaded_file, suffix: str) -> Optional[Path]:
    if uploaded_file is None:
        return None
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded_file.getbuffer())
    tmp.flush()
    return Path(tmp.name)


def format_factor_df(factors: List[Dict[str, Any]]) -> pd.DataFrame:
    if not factors:
        return pd.DataFrame(columns=["rank", "feature", "display_name", "value", "direction", "effect_or_hr", "plain_language"])
    rows = []
    for i, f in enumerate(factors, start=1):
        effect = f.get("effect_vs_baseline")
        if effect is None:
            effect = f.get("hazard_ratio")
        rows.append({
            "rank": i,
            "feature": f.get("feature"),
            "display_name": f.get("display_name"),
            "value": f.get("value"),
            "direction": f.get("direction"),
            "effect_or_hr": effect,
            "plain_language": f.get("plain_language"),
        })
    return pd.DataFrame(rows)



# ============================================================
# Gemma 4 LLM integration
# ============================================================
def _extract_gemma_text_from_rest_response(payload: Dict[str, Any]) -> str:
    """Extract text from Gemini/Gemma REST generateContent response."""
    texts: List[str] = []
    for cand in payload.get("candidates", []) or []:
        content = cand.get("content", {}) or {}
        for part in content.get("parts", []) or []:
            if isinstance(part, dict) and part.get("text"):
                texts.append(str(part.get("text")))
    return "\n".join(t.strip() for t in texts if t and t.strip()).strip()


def _safe_error_message(e: Exception, api_key: str = "") -> str:
    msg = str(e)
    if api_key:
        msg = msg.replace(api_key, "***API_KEY_REDACTED***")
    return msg[:500]


def call_gemma4_rest_api(
    api_key: str,
    model_name: str,
    prompt: str,
    temperature: float = 0.2,
    thinking_level: str = "off",
    timeout_sec: int = 35,
) -> str:
    """Call hosted Gemma 4 through the Gemini API REST endpoint.

    The REST path is intentionally used instead of relying only on the Python SDK,
    because Streamlit/Colab demos are more robust when the call has an explicit
    timeout and a visible fallback path.
    """
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent"
    body: Dict[str, Any] = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": float(temperature)},
    }
    if thinking_level == "high":
        body["generationConfig"]["thinkingConfig"] = {"thinkingLevel": "high"}

    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "x-goog-api-key": api_key,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            raw = resp.read().decode("utf-8")
            payload = json.loads(raw)
    except urllib.error.HTTPError as e:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8")[:700]
        except Exception:
            pass
        raise RuntimeError(f"Gemma 4 REST HTTP {e.code}: {err_body}")
    except Exception as e:
        raise RuntimeError(f"Gemma 4 REST request failed: {_safe_error_message(e, api_key)}")

    text = _extract_gemma_text_from_rest_response(payload)
    if not text:
        raise RuntimeError(f"Gemma 4 REST returned empty text: {json.dumps(payload, ensure_ascii=False)[:700]}")
    return text



def remove_prompt_echo_from_gemma_output(raw_text: str) -> str:
    """Remove Gemma prompt echo / instruction echo while preserving the final Traditional Chinese answer.

    Gemma 4 sometimes repeats the user prompt, safety rules, top_positive_factors,
    or JSON context before giving the answer. This function removes those prompt-like
    regions so the UI only shows the final explanation.
    """
    if not raw_text:
        return ""
    text = str(raw_text).replace("\r\n", "\n").replace("\r", "\n").strip()

    # Remove fenced blocks that are clearly prompt/context echoes.
    def _drop_bad_fence(match: re.Match) -> str:
        block = match.group(0)
        low = block.lower()
        bad_markers = [
            "json context", "top_positive_factors", "top_negative_factors",
            "provided json", "do not", "do *not*", "focus on", "constraint check",
            "mandatory disclaimer", "orn risk stratification", "classification probability",
            "cox risk score", "use traditional chinese", "max 5 bullet",
            "i will use", "i should", "skip to keep", "effect:",
        ]
        return "" if any(m in low for m in bad_markers) else block

    text = re.sub(r"```[\s\S]*?```", _drop_bad_fence, text)

    # Gemma sometimes returns the prompt echo as an indented Markdown code block
    # rather than a fenced ``` block. Streamlit renders that as the large gray box
    # seen in the UI. Remove those indented blocks before rendering.
    def _remove_indented_code_echo(src: str) -> str:
        out = []
        buf = []

        def flush_buf():
            nonlocal buf, out
            if not buf:
                return
            block = "\n".join(buf)
            low = block.lower()
            bad_markers = [
                "top_positive_factors", "top_negative_factors", "provided json",
                "do not", "do *not*", "focus on", "constraint check",
                "mandatory disclaimer", "orn risk stratification", "classification probability",
                "model predicted probability", "max 5 bullet", "i will use",
                "i should", "skip to keep", "effect:", "plain_language",
            ]
            # Prompt echoes are usually multi-line indented blocks, often with backticks,
            # English instructions, or raw factor/effect values. Drop the whole block.
            if len(buf) >= 2 or any(m in low for m in bad_markers) or "`" in block:
                buf = []
                return
            # Very short accidental indentation: keep it as normal text.
            out.extend([x.lstrip() for x in buf])
            buf = []

        for ln in src.split("\n"):
            if re.match(r"^( {4,}|\t)", ln):
                buf.append(ln)
            else:
                flush_buf()
                out.append(ln)
        flush_buf()
        return "\n".join(out)

    text = _remove_indented_code_echo(text)

    bad_line_markers = [
        "ORN Risk Stratification Model Output Controlled Assistant Explanation Module",
        "top_positive_factors", "top_negative_factors", "provided JSON", "JSON context",
        "Do NOT", "Do *not*", "Do not", "Focus on", "Explain *why*", "Max 5 bullet",
        "mandatory disclaimer", "Constraint Check", "Use Traditional Chinese",
        "classification probability", "Cox risk score", "partial hazard", "model predicted probability",
        "Output *only*", "Use `", "risk score", "generated content", "Gemma",
        "I will use", "I should", "Skip to keep", "effect:", "plain_language",
    ]

    kept = []
    in_prompt_echo = False
    for line in text.split("\n"):
        original = line.rstrip()
        stripped = original.strip()
        if not stripped:
            if kept and kept[-1] != "":
                kept.append("")
            continue
        low = stripped.lower()
        if any(m.lower() in low for m in bad_line_markers):
            in_prompt_echo = True
            continue
        # Remove prompt-style English bullets / numbered factor echoes. Keep lines with Chinese.
        has_cjk = bool(re.search(r"[\u4e00-\u9fff]", stripped))
        prompt_like = (
            stripped.startswith("*") or stripped.startswith("-") or re.match(r"^\d+\.\s*`", stripped)
        ) and not has_cjk
        if prompt_like:
            in_prompt_echo = True
            continue
        # Drop mostly-English prompt fragments without CJK after prompt echo begins.
        if in_prompt_echo and not has_cjk:
            continue
        # Drop standalone code/context remnants.
        if stripped in {"[", "]", "{", "}", "```", "*"}:
            continue
        kept.append(original)

    cleaned = "\n".join(kept).strip()

    # If a prompt echo header survived, cut from the first likely Traditional Chinese answer start.
    answer_starts = ["根據", "此病人", "這位病人", "本案例", "模型顯示", "主要", "以下", "可用於", "在此案例"]
    positions = [cleaned.find(x) for x in answer_starts if cleaned.find(x) >= 0]
    if positions:
        first = min(positions)
        if first > 0:
            cleaned = cleaned[first:].strip()

    # Remove duplicated long blank lines.
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
    return cleaned


def clean_or_fallback_gemma_answer(raw_text: str, case: Dict[str, Any], question: str) -> Dict[str, Any]:
    """Return cleaned Gemma answer. If Gemma only echoed the prompt, use the original safe summary.

    This keeps the v7 behavior/result style, but prevents prompt echo from appearing in the UI.
    """
    cleaned = remove_prompt_echo_from_gemma_output(raw_text)
    cjk_count = len(re.findall(r"[\u4e00-\u9fff]", cleaned))
    if cjk_count < 25:
        return {
            "text": generate_controlled_explanation(case, question),
            "prompt_echo_removed": True,
            "used_safe_summary_after_empty_clean": True,
        }
    return {
        "text": cleaned,
        "prompt_echo_removed": cleaned.strip() != str(raw_text).strip(),
        "used_safe_summary_after_empty_clean": False,
    }

def build_sidebar_llm_config() -> Dict[str, Any]:
    st.sidebar.subheader("LLM 介接設定")
    mode = st.sidebar.radio(
        "LLM 模式",
        ["Rule-based fallback", "Gemma 4 API"],
        index=0,
        help="Rule-based 為安全模板；Gemma 4 API 會將目前案例 JSON 傳送至 Google Gemini API 上的 Gemma 4 模型產生回覆。",
    )
    model_name = "gemma-4-26b-a4b-it"
    api_key = ""
    consent = False
    temperature = 0.2
    thinking_level = "off"
    timeout_sec = 35

    if mode == "Gemma 4 API":
        model_name = st.sidebar.selectbox(
            "Gemma 4 model",
            ["gemma-4-26b-a4b-it", "gemma-4-31b-it"],
            index=0,
            help="Google AI 文件目前列出的 Gemma 4 Gemini API hosted models。",
        )
        env_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY") or ""
        typed_key = st.sidebar.text_input(
            "Google AI API key",
            type="password",
            help="建議在 Colab 用環境變數設定，不要把 API key 寫進程式或論文截圖。",
        )
        api_key = typed_key.strip() or env_key.strip()
        if env_key and not typed_key:
            st.sidebar.caption("已偵測到環境變數 GOOGLE_API_KEY / GEMINI_API_KEY。")
        temperature = st.sidebar.slider("Temperature", 0.0, 1.0, 0.2, 0.1)
        thinking_level = st.sidebar.selectbox(
            "Gemma 4 thinking level",
            ["off", "high"],
            index=0,
            help="若模型/SDK 支援，high 會啟用 Gemma 4 thinking；失敗時系統會自動用一般 generate_content 重試。",
        )
        timeout_sec = st.sidebar.slider(
            "API timeout 秒數",
            min_value=10,
            max_value=90,
            value=35,
            step=5,
            help="Gemma 4 若超過此時間未回覆，介面會自動退回 rule-based fallback，避免按鈕看起來沒有反應。",
        )
        consent = st.sidebar.checkbox(
            "我了解會將目前案例 JSON 傳送至 Gemma 4 API 產生說明",
            value=False,
        )
        if not api_key:
            st.sidebar.warning("尚未提供 Google AI API key，將自動改用 Rule-based fallback。")
        elif not consent:
            st.sidebar.warning("尚未勾選同意傳送 JSON，將自動改用 Rule-based fallback。")
        else:
            st.sidebar.success("Gemma 4 API 已設定。按鈕回覆若超時會顯示 fallback reason。")

    return {
        "mode": mode,
        "model_name": model_name,
        "api_key": api_key,
        "temperature": temperature,
        "thinking_level": thinking_level,
        "timeout_sec": timeout_sec,
        "consent": consent,
    }


def action_instruction(action: str) -> str:
    mapping = {
        "threshold": (
            "請只說明此案例的風險分層門檻與模型陽性/需關注門檻之差異。"
            "若是 Cox 模型，請強調 risk score 是相對風險，不是百分比機率。"
        ),
        "main_risk": (
            "請聚焦說明 top_positive_factors 中最主要的風險來源，逐項說明為何模型可能將其視為提高風險。"
            "不要討論 JSON 未提供的因素。"
        ),
        "lower_risk": (
            "請只整理 top_negative_factors 或降低/未提高風險因素。若 JSON 沒有提供，請明確說明目前資料未提供降低風險因子。"
        ),
        "image_info": (
            "請只說明影像相關資訊，例如 panoramic X-ray image-derived representation、img_pc 或影像模型 probability。"
            "不要把影像特徵說成確診依據；img_pc 只能解釋為影像潛在表徵。"
        ),
        "physician_summary": (
            "請產生一段 120 到 180 字的醫師摘要，包含分數、分層、主要因素與限制聲明。"
            "語氣要中性，避免治療建議。"
        ),
        "free_question": "請回答使用者問題，但只能根據 JSON 中已有模型輸出、門檻、因素與限制回答。",
    }
    return mapping.get(action, mapping["free_question"])


def build_gemma_prompt(case: Dict[str, Any], question: str, action: str) -> str:
    # Reduce the chance of leaking UI-only large objects while still preserving traceability.
    context = json.dumps(make_json_serializable(case), ensure_ascii=False, indent=2)
    return f"""
你是「ORN 風險分層模型輸出」的受控式輔助解釋模組。你不是醫師，也不是診斷模型。

【任務】
{action_instruction(action)}

【使用者問題或按鈕】
{question}

【必須遵守的安全規則】
1. 只能根據下方 JSON 內容回答，不可新增 JSON 沒有提供的病史、症狀、影像徵象或治療資訊。
2. 不可重新計算、修改或質疑 JSON 中的 risk score、predicted probability、risk group、threshold。
3. 不可提供診斷、治療建議、用藥建議或保證性結論。
4. 若是 classification probability，請稱為模型預測機率或風險分數。
5. 若是 Cox risk score / partial hazard，請明確說它是相對風險，不是 ORN 發生機率百分比。
6. 回覆最後必須保留限制聲明：本系統為 ORN 風險分層輔助工具，不取代臨床診斷或醫師判斷。
7. 使用繁體中文，內容要清楚、精簡，除非使用者要求，不要超過 5 個條列點。

【JSON context】
```json
{context}
```
""".strip()


def generate_gemma_explanation(case: Dict[str, Any], question: str, action: str, llm_config: Dict[str, Any]) -> Dict[str, Any]:
    if not llm_config.get("api_key") or not llm_config.get("consent"):
        raise RuntimeError("Gemma 4 API key or consent is missing.")

    prompt = build_gemma_prompt(case, question, action)
    model_name = llm_config.get("model_name", "gemma-4-26b-a4b-it")
    temperature = float(llm_config.get("temperature", 0.2))
    thinking_level = llm_config.get("thinking_level", "off")
    timeout_sec = int(llm_config.get("timeout_sec", 35))

    # Primary path: explicit REST call with timeout. This avoids the UI appearing to
    # do nothing when the hosted model is slow or when the SDK has a version mismatch.
    raw_text = call_gemma4_rest_api(
        api_key=llm_config.get("api_key"),
        model_name=model_name,
        prompt=prompt,
        temperature=temperature,
        thinking_level=thinking_level,
        timeout_sec=timeout_sec,
    )
    cleaned = clean_or_fallback_gemma_answer(raw_text, case, question)
    return {
        "text": cleaned["text"].strip(),
        "meta": {
            "llm_mode": "Gemma 4 API",
            "model": model_name,
            "thinking_level": thinking_level,
            "api_method": "REST",
            "fallback_used": False,
            "prompt_echo_removed": cleaned.get("prompt_echo_removed", False),
            "used_safe_summary_after_empty_clean": cleaned.get("used_safe_summary_after_empty_clean", False),
        },
    }


def validate_llm_response(answer: str, case: Dict[str, Any]) -> Dict[str, Any]:
    forbidden = ["確診", "保證", "一定會發生", "取代醫師", "立即治療", "必須治療"]
    found = [w for w in forbidden if w in answer]
    pred = case.get("prediction", {})
    risk_group = str(pred.get("risk_group", ""))
    risk_zh = risk_label_zh(risk_group)
    mentions_group = (risk_group and risk_group in answer) or (risk_zh and risk_zh in answer)

    score_ok = True
    score_note = "not_checked"
    try:
        if case.get("case_type") == "multimodal_survival_cox":
            score = pred.get("risk_score")
            if score is not None:
                score_str = metric_fmt(score, 3)
                score_ok = score_str in answer or metric_fmt(score, 2) in answer
                score_note = f"expected Cox risk_score around {score_str}"
        else:
            prob = pred.get("predicted_probability")
            if prob is not None:
                prob_str = f"{float(prob):.1%}"
                score_ok = prob_str in answer
                score_note = f"expected probability {prob_str}"
    except Exception:
        score_ok = True

    return {
        "forbidden_terms_found": found,
        "forbidden_terms_pass": len(found) == 0,
        "risk_group_mentioned": bool(mentions_group),
        "score_consistency_pass": bool(score_ok),
        "score_note": score_note,
    }


def generate_explanation(case: Dict[str, Any], question: str, action: str, llm_config: Dict[str, Any]) -> Dict[str, Any]:
    """Generate explanation by Gemma 4 when enabled; otherwise use deterministic fallback."""
    if llm_config.get("mode") == "Gemma 4 API" and llm_config.get("api_key") and llm_config.get("consent"):
        try:
            out = generate_gemma_explanation(case, question, action, llm_config)
            safety = validate_llm_response(out["text"], case)
            out["meta"].update({"safety": safety})
            return out
        except Exception as e:
            answer = generate_controlled_explanation(case, question)
            safety = validate_llm_response(answer, case)
            return {
                "text": answer,
                "meta": {
                    "llm_mode": "Rule-based fallback",
                    "fallback_used": True,
                    "fallback_reason": str(e)[:300],
                    "safety": safety,
                },
            }

    answer = generate_controlled_explanation(case, question)
    safety = validate_llm_response(answer, case)
    return {
        "text": answer,
        "meta": {
            "llm_mode": "Rule-based fallback",
            "fallback_used": False,
            "safety": safety,
        },
    }

# ============================================================
# Controlled explanation
# ============================================================
def factor_bullets(factors: List[Dict[str, Any]], max_items: int = 5) -> str:
    if not factors:
        return "目前 JSON 沒有提供主要因素。"
    out = []
    for f in factors[:max_items]:
        display = f.get("display_name") or f.get("feature", "未知變項")
        value = f.get("value", "未提供")
        if "effect_vs_baseline" in f:
            metric = f"相對基準影響約 {float(f['effect_vs_baseline']):+.1%}"
        elif "hazard_ratio" in f:
            metric = f"HR={metric_fmt(f.get('hazard_ratio'))}"
        else:
            metric = "模型提供之解釋因子"
        plain = f.get("plain_language", "")
        out.append(f"- **{display}**（值：{value}；{metric}）：{plain}")
    return "\n".join(out)


def generate_controlled_explanation(case: Dict[str, Any], question: str) -> str:
    pred = case.get("prediction", {})
    exp = case.get("explanation", {})
    guardrails = case.get("llm_guardrails", {})
    case_type = case.get("case_type", "")
    risk_group = pred.get("risk_group", "Unknown")
    risk_zh = risk_label_zh(risk_group)
    disclaimer = guardrails.get("required_disclaimer", "本系統為風險分層輔助工具，不取代臨床診斷或醫師判讀。")
    q = question.lower().strip()

    positive = exp.get("top_positive_factors", [])
    negative = exp.get("top_negative_factors", [])

    if case_type == "multimodal_survival_cox":
        risk_score = pred.get("risk_score")
        threshold = pred.get("thresholds", {}).get("high_vs_low_median", "未設定")
        base = (
            f"此病人的 Cox 相對風險分數為 **{metric_fmt(risk_score)}**，分層為 **{risk_zh}**。"
            f"分層門檻是訓練 cohort 的 median risk score（{metric_fmt(threshold)}）。\n\n"
            "需要注意：這是 **relative risk score / partial hazard**，不是 72% 這種絕對發生機率。\n\n"
        )
    else:
        prob = float(pred.get("predicted_probability", 0))
        thresholds = pred.get("thresholds", {})
        low_thr = thresholds.get("low_to_intermediate", "未設定")
        high_thr = thresholds.get("intermediate_to_high", "未設定")
        positive_thr = thresholds.get("classification_positive_threshold", thresholds.get("positive_threshold", None))
        status_txt = ""
        if positive_thr is not None:
            try:
                status_txt = f"另外，模型陽性/需關注門檻為 **{float(positive_thr):.1%}**；此病人分數 {'高於' if prob >= float(positive_thr) else '低於'}該門檻。"
            except Exception:
                status_txt = f"另外，模型陽性/需關注門檻為 **{positive_thr}**。"
        base = (
            f"此病人的模型預測分數為 **{prob:.1%}**，目前顯示分層為 **{risk_zh}**。"
            f"本介面顯示分層門檻為：Low < **{low_thr}**，Intermediate < **{high_thr}**，High ≥ **{high_thr}**。"
            f"{status_txt}\n\n"
            "需要區分：**風險分層門檻**用來讓介面分成低/中/高；"
            "**模型陽性門檻**通常是為了篩檢敏感度最佳化，數值可能比較低，不能直接等同於高風險。\n\n"
        )

    if any(k in q for k in ["門檻", "threshold", "48", "分層", "陽性"]):
        return (
            base
            + "目前案例需要特別注意門檻定義：如果看到 48% 卻被標成高風險，通常是因為系統把『模型陽性門檻』誤當成『高風險分層門檻』。"
            + "新版介面已將兩者分開：48% 通常會落在中風險，而不是高風險；但若陽性門檻約 23%，它仍會被視為模型判定需要關注。\n\n"
            + disclaimer
        )
    if any(k in q for k in ["為什麼", "原因", "why", "高風險", "解釋", "風險"]):
        return base + "主要提高風險的模型因素包括：\n" + factor_bullets(positive) + "\n\n" + disclaimer
    if any(k in q for k in ["降低", "保護", "低風險", "negative", "decrease"]):
        return base + "模型中相對降低風險或使分數下降的因素包括：\n" + factor_bullets(negative) + "\n\n" + disclaimer
    if any(k in q for k in ["影像", "xray", "x-ray", "img_pc", "panoramic"]):
        image_factors = [
            f for f in positive + negative
            if str(f.get("feature", "")).startswith("img_pc")
            or "image" in str(f.get("feature", "")).lower()
            or "panoramic" in str(f.get("feature", "")).lower()
        ]
        if not image_factors:
            return base + "此 JSON 沒有提供可單獨拆解的影像因子。若使用 Cox 多模態模型，img_pc 是影像特徵經 PCA 降維後的潛在特徵，不能直接解讀為某個明確病灶。\n\n" + disclaimer
        return base + "與影像相關的模型訊號如下：\n" + factor_bullets(image_factors) + "\n\n" + disclaimer
    if any(k in q for k in ["摘要", "醫師", "summary"]):
        return base + "可用於摘要的重點如下：\n" + factor_bullets(positive, max_items=3) + "\n\n" + disclaimer
    return base + "目前我只能根據 JSON 中已存在的模型輸出、分層門檻與解釋因子回答。\n\n主要提高風險因素：\n" + factor_bullets(positive, max_items=3) + "\n\n" + disclaimer


# ============================================================
# Renderers
# ============================================================
def render_header() -> None:
    st.markdown(
        f"""
        <div class="hero">
            <div class="hero-title">{APP_TITLE}</div>
            <div class="hero-subtitle">
                模型負責計算風險；LLM 只根據固定 JSON 解釋結果。支援臨床分類模型、多模態 Cox 生存模型與影像 pipeline 結果檢視。
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_summary_card(case: Dict[str, Any]) -> None:
    patient = case.get("patient", {})
    pred = case.get("prediction", {})
    risk_group = pred.get("risk_group", "Unknown")
    color = risk_badge_color(risk_group)
    case_type = case.get("case_type", "")

    if case_type == "multimodal_survival_cox":
        main_value = metric_fmt(pred.get("risk_score"), 3)
        main_label = "Relative risk score"
        note = pred.get("interpretation_note", "Cox risk score 為相對風險，不是絕對機率。")
    else:
        prob = float(pred.get("predicted_probability", 0))
        main_value = f"{prob:.1%}"
        main_label = "Predicted probability"
        note = pred.get("interpretation_note", "分類模型輸出的風險機率。")

    extra = ""
    status = get_classification_positive_status(case)
    if status is not None:
        extra = (
            f"<div class='threshold-box'>"
            f"模型陽性/需關注門檻：<b>{status['positive_threshold']:.1%}</b>；"
            f"目前狀態：<b>{'高於門檻，建議關注' if status['is_model_positive'] else '低於門檻'}</b><br>"
            f"顯示分層與陽性門檻已分開，避免把低門檻篩檢結果誤解成高風險。"
            f"</div>"
        )

    st.markdown(
        f"""
        <div class="risk-card">
            <div class="small-label">Patient ID</div>
            <div class="patient-id">{patient.get('patient_id', 'NA')}</div>
            <br />
            <div class="small-label">{main_label}</div>
            <div class="risk-number">{main_value}</div>
            <span class="risk-badge" style="background:{color};">{risk_label_zh(risk_group)} / {risk_group}</span>
            <div class="note-box">{note}</div>
            {extra}
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_metrics(case: Dict[str, Any]) -> None:
    perf = case.get("model_performance", {})
    flat_perf = flatten_numeric_metrics(perf)
    preferred = [
        "roc_auc", "brier_score", "ece", "sensitivity", "specificity",
        "multimodal_cindex", "clinical_only_cindex", "cindex_improvement", "logrank_p_high_vs_low",
        "patient_level_oof.auroc", "patient_level_oof.f1", "patient_level_oof.sensitivity", "patient_level_oof.specificity",
        "image_level_oof.auroc", "image_level_oof.f1", "image_level_oof.sensitivity", "image_level_oof.specificity",
        "patient_level_cv.patient_level_auroc_mean", "patient_level_cv.patient_level_auroc_std",
    ]
    show_keys = [k for k in preferred if k in flat_perf]
    if not show_keys:
        show_keys = [k for k, v in flat_perf.items() if not isinstance(v, dict)][:4]
    cols = st.columns(4)
    for i, k in enumerate(show_keys[:4]):
        cols[i].metric(format_metric_name(k), metric_display_value(flat_perf.get(k)))

    # For image pipeline outputs, metrics are nested dictionaries; show all flattened
    # numeric values so AUROC/F1/sensitivity/specificity do not disappear.
    if flat_perf:
        rows = []
        for k, v in flat_perf.items():
            if isinstance(v, dict):
                continue
            rows.append({"metric": format_metric_name(k), "raw_key": k, "value": metric_display_value(v)})
        if rows:
            with st.expander("查看完整模型效能數值", expanded=(case.get("case_type") == "image_classification_result")):
                st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)




def render_llm_validation_metrics(bs: Dict[str, Any], meta: Dict[str, Any]) -> None:
    """Show LLM validation metrics with the same visual weight as model metrics."""
    st.markdown("**LLM 驗證指標**")
    c1, c2, c3 = st.columns(3)
    c1.metric("BERTScore F1", metric_display_value(bs.get("f1")))
    c2.metric("BERTScore P", metric_display_value(bs.get("precision")))
    c3.metric("BERTScore R", metric_display_value(bs.get("recall")))

    safety = meta.get("safety", {}) if isinstance(meta, dict) else {}
    c4, c5, c6 = st.columns(3)
    c4.metric("禁用語句檢查", "Pass" if safety.get("forbidden_terms_pass", True) else "Fail")
    c5.metric("分數一致性", "Pass" if safety.get("score_consistency_pass", True) else "Check")
    c6.metric("分層提及", "Yes" if safety.get("risk_group_mentioned", False) else "No")

    method = bs.get("method", "NA")
    model = meta.get("model", "NA") if isinstance(meta, dict) else "NA"
    mode = meta.get("llm_mode", "NA") if isinstance(meta, dict) else "NA"
    thinking = meta.get("thinking_level", "NA") if isinstance(meta, dict) else "NA"
    st.caption(f"method：{method} ｜ LLM mode：{mode} ｜ model：{model} ｜ thinking：{thinking}")
    if isinstance(meta, dict) and meta.get("fallback_reason"):
        with st.expander("Gemma 4 fallback / debug reason", expanded=False):
            st.write(meta.get("fallback_reason"))
    if isinstance(meta, dict) and meta.get("prompt_echo_removed"):
        st.caption("Gemma 4 prompt echo 已自動隱藏，主畫面僅呈現最終中文解釋。")
    if str(method).startswith("fallback"):
        st.caption("注意：目前未成功載入 bert_score 套件或模型，這是文字重疊 fallback，不可作為正式論文 BERTScore。")

def render_prediction_values(case: Dict[str, Any]) -> None:
    patient = case.get("patient", {})
    row = patient.get("available_prediction_row")
    if not isinstance(row, dict) or not row:
        return
    preferred = [
        "prob", "prob_positive", "predicted_probability", "threshold", "pred_patient", "y_pred", "y_true",
        "n_images", "fold", "model_name", "aug_mode", "image_name", "patient_level_auroc", "image_level_auroc",
    ]
    keys = [k for k in preferred if k in row] + [k for k in row.keys() if k not in preferred]
    pred_rows = []
    for k in keys:
        v = row.get(k)
        pred_rows.append({"欄位": k, "值": metric_display_value(v) if isinstance(v, (int, float, list)) else v})
    with st.expander("查看此病人的影像 prediction row 數值", expanded=(case.get("case_type") == "image_classification_result")):
        st.dataframe(pd.DataFrame(pred_rows), use_container_width=True, hide_index=True)


def render_case(case: Dict[str, Any], llm_config: Dict[str, Any]) -> None:
    left, right = st.columns([1.05, 1.25], gap="large")
    with left:
        render_summary_card(case)
        st.subheader("模型效能 / 輸出資訊")
        render_metrics(case)
        render_prediction_values(case)
        tab1, tab2, tab3 = st.tabs(["主要提高風險因素", "降低或未提高風險因素", "JSON context"])
        with tab1:
            st.dataframe(format_factor_df(case.get("explanation", {}).get("top_positive_factors", [])), use_container_width=True, hide_index=True)
        with tab2:
            st.dataframe(format_factor_df(case.get("explanation", {}).get("top_negative_factors", [])), use_container_width=True, hide_index=True)
        with tab3:
            st.json(case)
            st.download_button(
                "下載此案例 JSON",
                data=json.dumps(case, ensure_ascii=False, indent=2),
                file_name=f"orn_case_{case.get('patient', {}).get('patient_id', 'case')}.json",
                mime="application/json",
            )
    with right:
        st.subheader("LLM 輔助解釋對話框")
        st.caption(f"LLM 模式：{llm_config.get('mode')}。Gemma 4 失敗或未授權時會自動回到 rule-based fallback。")

        case_key = f"{case.get('case_type','case')}::{case.get('patient',{}).get('patient_id','unknown')}"
        if st.session_state.get("active_case_key") != case_key:
            st.session_state["active_case_key"] = case_key
            st.session_state["chat_messages"] = []

        st.markdown("<div class='chat-panel'><div class='quick-title'>選擇功能，或直接在下方輸入問題</div>", unsafe_allow_html=True)
        qa_cols = st.columns(3)
        quick_actions = [
            ("說明分層門檻", "threshold", "請說明這位病人的風險分層門檻，以及模型陽性門檻和高風險門檻的差異。"),
            ("解釋主要風險", "main_risk", "為什麼這位病人的模型風險較高？請聚焦主要提高風險因子。"),
            ("列出降低風險因子", "lower_risk", "有哪些因素降低或未提高這位病人的風險？"),
            ("影像資訊怎麼看", "image_info", "影像或 img_pc 特徵在這位病人的結果中代表什麼？"),
            ("產生醫師摘要", "physician_summary", "請產生一段可以放在臨床風險摘要中的文字。"),
            ("清空對話", "clear", "__CLEAR__"),
        ]
        selected_prompt = None
        selected_action = None
        for idx, (label, action, prompt) in enumerate(quick_actions):
            if qa_cols[idx % 3].button(label, key=f"quick_{idx}_{case_key}", use_container_width=True):
                selected_prompt = prompt
                selected_action = action
        st.markdown("</div>", unsafe_allow_html=True)

        if selected_prompt == "__CLEAR__":
            st.session_state["chat_messages"] = []
            st.rerun()
        elif selected_prompt:
            st.session_state["chat_messages"].append({"role": "user", "content": selected_prompt})
            with st.spinner(f"正在呼叫 {llm_config.get('mode')} 產生說明；若 Gemma 4 超時會自動 fallback..."):
                out = generate_explanation(case, selected_prompt, selected_action or "free_question", llm_config)
                answer = out["text"]
            with st.spinner("正在計算 LLM 驗證指標（BERTScore / 安全檢查）..."):
                bs = compute_bertscore_cached(answer, build_reference_explanation(case))
            st.session_state["chat_messages"].append({"role": "assistant", "content": answer, "bertscore": bs, "llm_meta": out.get("meta", {})})
            st.rerun()

        for m in st.session_state.get("chat_messages", []):
            with st.chat_message(m["role"]):
                st.markdown(m["content"])
                if m.get("bertscore"):
                    render_llm_validation_metrics(m["bertscore"], m.get("llm_meta", {}))
                elif m.get("llm_meta"):
                    meta = m["llm_meta"]
                    safety = meta.get("safety", {})
                    safety_txt = (
                        f"禁用語句：{'Pass' if safety.get('forbidden_terms_pass', True) else 'Fail'}；"
                        f"分數一致性：{'Pass' if safety.get('score_consistency_pass', True) else 'Check'}；"
                        f"風險分層提及：{'Yes' if safety.get('risk_group_mentioned', False) else 'No'}"
                    )
                    st.caption(f"LLM mode：{meta.get('llm_mode')} ｜ model：{meta.get('model', 'NA')} ｜ {safety_txt}")
                    if meta.get("fallback_reason"):
                        with st.expander("Gemma 4 fallback / debug reason", expanded=False):
                            st.write(meta.get("fallback_reason"))

        user_q = st.chat_input("自行輸入問題，例如：為什麼這位病人是中風險？")
        if user_q:
            st.session_state["chat_messages"].append({"role": "user", "content": user_q})
            with st.spinner(f"正在呼叫 {llm_config.get('mode')} 產生說明；若 Gemma 4 超時會自動 fallback..."):
                out = generate_explanation(case, user_q, "free_question", llm_config)
                answer = out["text"]
            with st.spinner("正在計算 LLM 驗證指標（BERTScore / 安全檢查）..."):
                bs = compute_bertscore_cached(answer, build_reference_explanation(case))
            st.session_state["chat_messages"].append({"role": "assistant", "content": answer, "bertscore": bs, "llm_meta": out.get("meta", {})})
            st.rerun()


# ============================================================
# Case loading modes
# ============================================================
def mode_json_case() -> Optional[Dict[str, Any]]:
    st.sidebar.subheader("JSON 輸入")
    uploaded = st.sidebar.file_uploader("上傳 case JSON", type=["json"])
    if uploaded is not None:
        return json.load(uploaded)
    sample = Path("sample_json/clinical_case_example.json")
    return load_json_default(sample)


def mode_clinical_bundle() -> Optional[Dict[str, Any]]:
    st.sidebar.subheader("臨床分類模型")
    bundle_path = Path("clinical_model_bundle.joblib")
    uploaded_bundle = st.sidebar.file_uploader("上傳 clinical_model_bundle.joblib", type=["joblib", "pkl"], key="clinical_bundle")
    if uploaded_bundle is not None:
        tmp = save_uploaded_to_temp(uploaded_bundle, ".joblib")
        bundle = load_clinical_bundle(tmp)
    elif bundle_path.exists():
        bundle = load_clinical_bundle(bundle_path)
    else:
        st.info("尚未找到 clinical_model_bundle.joblib。請先執行 train_clinical_bundle.py，或在左側上傳 bundle。")
        return None
    patients = bundle["patient_source_table"][CLINICAL_ID].astype(str).tolist()
    patient_id = st.sidebar.selectbox("選擇病人 ipatient", patients)
    return case_json_from_clinical_patient(bundle, patient_id)


def mode_survival_bundle() -> Optional[Dict[str, Any]]:
    st.sidebar.subheader("多模態 Cox 生存模型")
    bundle_path = Path("survival_model_bundle.joblib")
    uploaded_bundle = st.sidebar.file_uploader("上傳 survival_model_bundle.joblib", type=["joblib", "pkl"], key="survival_bundle")
    if uploaded_bundle is not None:
        tmp = save_uploaded_to_temp(uploaded_bundle, ".joblib")
        bundle = load_survival_bundle(tmp)
    elif bundle_path.exists():
        bundle = load_survival_bundle(bundle_path)
    else:
        st.info("尚未找到 survival_model_bundle.joblib。請先執行 train_survival_bundle.py，或在左側上傳 bundle。")
        return None
    meta = bundle.get("metadata", {})
    id_col = meta.get("id_col", "ipatient")
    patients = bundle["patient_risk_table"][id_col].astype(str).tolist()
    patient_id = st.sidebar.selectbox("選擇病人 ipatient", patients)
    return case_json_from_survival_patient(bundle, patient_id)


def mode_image_results() -> Optional[Dict[str, Any]]:
    st.sidebar.subheader("影像 pipeline 結果檢視")
    pred_file = st.sidebar.file_uploader("上傳 cv_patient_level_predictions_all_folds.csv", type=["csv", "xlsx"], key="image_pred")
    summary_file = st.sidebar.file_uploader("可選：上傳 cv_metrics_summary.json", type=["json"], key="image_summary")
    if pred_file is None:
        st.info("請上傳 orn_image_baseline_pipeline_v7_compare.py 輸出的 cv_patient_level_predictions_all_folds.csv。")
        return None
    suffix = ".xlsx" if pred_file.name.lower().endswith((".xlsx", ".xls")) else ".csv"
    pred_path = save_uploaded_to_temp(pred_file, suffix)
    pred_df = read_csv_or_excel(pred_path)
    summary: Dict[str, Any] = {}
    if summary_file is not None:
        summary = json.load(summary_file)
    patients = pred_df["ipatient"].astype(str).unique().tolist()
    patient_id = st.sidebar.selectbox("選擇病人 ipatient", patients)
    return case_json_from_image_predictions(pred_df, patient_id, metrics_summary=summary)


def main() -> None:
    st.set_page_config(page_title="ORN Risk UI", page_icon="🦷", layout="wide")
    inject_css()
    render_header()

    st.sidebar.title("資料來源")
    mode = st.sidebar.radio(
        "選擇模式",
        [
            "JSON 範例 / 上傳",
            "臨床分類模型 bundle",
            "多模態 Cox 生存模型 bundle",
            "影像 pipeline 結果檢視",
        ],
    )
    llm_config = build_sidebar_llm_config()

    try:
        if mode == "JSON 範例 / 上傳":
            case = mode_json_case()
        elif mode == "臨床分類模型 bundle":
            case = mode_clinical_bundle()
        elif mode == "多模態 Cox 生存模型 bundle":
            case = mode_survival_bundle()
        else:
            case = mode_image_results()
    except Exception as e:
        st.error(f"載入失敗：{e}")
        return

    if case is None:
        st.stop()

    # Avoid JSON serialization errors from numpy/pandas scalar values in generated cases.
    case = make_json_serializable(case)

    if case.get("case_type") == "multimodal_survival_cox":
        st.markdown("<div class='warn-box'>目前為 Cox 生存模型：risk_score 是相對風險，不是百分比機率。</div>", unsafe_allow_html=True)
    else:
        st.markdown("<div class='note-box'>目前為分類模型或結果表：predicted_probability 可作為風險分數顯示。</div>", unsafe_allow_html=True)

    render_case(case, llm_config)


if __name__ == "__main__":
    main()
