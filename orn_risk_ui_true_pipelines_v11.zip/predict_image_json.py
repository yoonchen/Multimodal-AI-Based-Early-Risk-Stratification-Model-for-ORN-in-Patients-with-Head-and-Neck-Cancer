from __future__ import annotations

import argparse
import json
from pathlib import Path

from image_results_backend import read_csv_or_excel, load_optional_json, case_json_from_image_predictions


def main() -> None:
    parser = argparse.ArgumentParser(description="Export one image-pipeline result case JSON.")
    parser.add_argument("--prediction_table", type=str, required=True, help="cv_patient_level_predictions_all_folds.csv")
    parser.add_argument("--metrics_summary", type=str, default=None, help="Optional cv_metrics_summary.json")
    parser.add_argument("--patient_id", type=str, required=True)
    parser.add_argument("--output_json", type=str, default="image_case_real.json")
    args = parser.parse_args()

    pred_df = read_csv_or_excel(args.prediction_table)
    summary = load_optional_json(args.metrics_summary)
    case = case_json_from_image_predictions(pred_df, args.patient_id, metrics_summary=summary)
    Path(args.output_json).write_text(json.dumps(case, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Saved:", Path(args.output_json).resolve())


if __name__ == "__main__":
    main()
