from __future__ import annotations

import argparse
import json
from pathlib import Path

from survival_backend import load_bundle, case_json_from_survival_patient


def main() -> None:
    parser = argparse.ArgumentParser(description="Export one survival prediction case JSON.")
    parser.add_argument("--bundle_path", type=str, default="survival_model_bundle.joblib")
    parser.add_argument("--patient_id", type=str, required=True)
    parser.add_argument("--output_json", type=str, default="survival_case_real.json")
    args = parser.parse_args()

    bundle = load_bundle(args.bundle_path)
    case = case_json_from_survival_patient(bundle, args.patient_id)
    Path(args.output_json).write_text(json.dumps(case, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Saved:", Path(args.output_json).resolve())


if __name__ == "__main__":
    main()
