from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from PIL import Image, ImageFile

import torch
from torch import nn
from torchvision import models, transforms

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from lifelines import CoxPHFitter
from lifelines.statistics import logrank_test

ImageFile.LOAD_TRUNCATED_IMAGES = True
IMG_EXTS = [".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"]

ID_COL = "ipatient"

FEATURE_DISPLAY = {
    "mandible_resection_worst": "Mandible resection severity",
    "reconstruction_max": "Reconstruction severity",
    "tooth_extraction_count": "Tooth extraction count",
    "neck_dissection_pre_orn_any": "Neck dissection before ORN/censoring",
    "Tumor location_grouped_Hypopharynx / Larynx": "Tumor location: hypopharynx/larynx",
    "Tumor location_grouped_Nasopharynx": "Tumor location: nasopharynx",
    "Tumor location_grouped_Oral cavity": "Tumor location: oral cavity",
    "Tumor location_grouped_Oropharynx": "Tumor location: oropharynx",
    "Tumor location_grouped_Other": "Tumor location: other",
    "Tumor location_grouped_Salivary gland": "Tumor location: salivary gland",
    "年齡": "Age",
    "ECOG": "ECOG performance status",
    "img_pc1": "Image-derived PC1",
    "img_pc2": "Image-derived PC2",
    "img_pc3": "Image-derived PC3",
    "n_images": "Number of panoramic images",
}

PLAIN_LANGUAGE = {
    "mandible_resection_worst": "下顎骨切除程度較高，通常代表局部治療或骨組織受影響程度較大，因此可能提高相對風險。",
    "reconstruction_max": "重建方式越複雜，可能反映手術範圍較大或局部組織缺損較明顯。",
    "tooth_extraction_count": "拔牙次數較多可能代表局部骨癒合壓力較高，模型將其納入相對風險評估。",
    "neck_dissection_pre_orn_any": "頸部廓清紀錄可能反映治療範圍與疾病嚴重度，需與其他因素一起判讀。",
    "年齡": "年齡可能反映修復能力與共病負擔，Cox 模型會將其納入相對風險估計。",
    "ECOG": "ECOG 較高通常代表整體功能狀態較差，可能與治療後恢復能力下降有關。",
    "img_pc1": "img_pc 是由 panoramic X-ray 影像特徵經 PCA 降維後得到的潛在影像特徵，不等同於人工標註的單一放射學徵象。",
    "img_pc2": "img_pc 是由 panoramic X-ray 影像特徵經 PCA 降維後得到的潛在影像特徵，不等同於人工標註的單一放射學徵象。",
    "img_pc3": "img_pc 是由 panoramic X-ray 影像特徵經 PCA 降維後得到的潛在影像特徵，不等同於人工標註的單一放射學徵象。",
}


def safe_strip_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def find_first_existing_column(df: pd.DataFrame, candidates: Sequence[str]) -> Optional[str]:
    for c in candidates:
        if c in df.columns:
            return c
    return None


def normalize_text_series(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower()


def robust_map_mandible_worst(s: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_numeric(s, errors="coerce")
    x = normalize_text_series(s)
    mapping = {
        "none": 0, "no": 0, "0": 0,
        "marginal": 1, "marginal resection": 1, "1": 1,
        "segmental": 2, "segmental resection": 2, "2": 2,
    }
    return x.map(mapping)


def robust_map_reconstruction_max(s: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_numeric(s, errors="coerce")
    x = normalize_text_series(s)
    mapping = {
        "none": 0, "no reconstruction": 0, "0": 0,
        "local flap": 1, "local": 1, "1": 1,
        "regional flap": 2, "regional": 2, "2": 2,
        "free flap": 3, "free": 3, "3": 3,
    }
    return x.map(mapping)


def group_tumor_location(x: pd.Series) -> pd.Series:
    s = x.astype(str).str.strip()
    mapping = {
        "Gum": "Oral cavity",
        "Buccal / other oral cavity": "Oral cavity",
        "Floor of mouth": "Oral cavity",
        "Tongue": "Oral cavity",
        "Lip": "Oral cavity",
        "Palate": "Oral cavity",
        "Base of tongue": "Oropharynx",
        "Tonsil": "Oropharynx",
        "Oropharynx": "Oropharynx",
        "Hypopharynx": "Hypopharynx / Larynx",
        "Larynx": "Hypopharynx / Larynx",
        "Pyriform sinus": "Hypopharynx / Larynx",
        "Nasopharynx": "Nasopharynx",
        "Parotid gland": "Salivary gland",
        "Other major salivary glands": "Salivary gland",
    }
    out = s.map(mapping).fillna("Other")
    out = out.replace({"nan": "Other", "None": "Other", "": "Other"})
    return out


def winsorize_series(s: pd.Series, lower_q=0.01, upper_q=0.99) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce")
    if s.notna().sum() == 0:
        return s
    return s.clip(lower=s.quantile(lower_q), upper=s.quantile(upper_q))


def candidate_stems_from_row(row: pd.Series) -> List[str]:
    candidates = []
    for col in ["image_name", "image_name_std", "image_id"]:
        if col in row and pd.notna(row[col]):
            raw = str(row[col]).strip()
            if raw and raw.lower() != "nan":
                candidates.append(raw)
    out = []
    seen = set()
    for x in candidates:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def resolve_image_paths(row: pd.Series, image_root: Path) -> List[Path]:
    stems = candidate_stems_from_row(row)
    matched = []
    for p in image_root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in IMG_EXTS:
            continue
        file_stem = p.stem.strip()
        for stem in stems:
            if file_stem == stem or file_stem.startswith(stem + "-") or file_stem.startswith(stem + "_"):
                matched.append(p.resolve())
                break
    return sorted({str(p): p for p in matched}.values(), key=lambda x: str(x))


def expand_rows_to_images(image_df: pd.DataFrame, image_root: Path, output_dir: Path) -> pd.DataFrame:
    rows = []
    unresolved = []
    for _, row in image_df.iterrows():
        paths = resolve_image_paths(row, image_root)
        if not paths:
            unresolved.append(row.to_dict())
            continue
        for p in paths:
            new_row = row.copy()
            new_row["image_path"] = str(p)
            new_row["resolved_filename"] = p.name
            rows.append(new_row)
    if unresolved:
        pd.DataFrame(unresolved).to_csv(output_dir / "missing_image_paths.csv", index=False, encoding="utf-8-sig")
    return pd.DataFrame(rows)


class ImageFeatureExtractor:
    def __init__(self, device: torch.device, img_size: int = 224, batch_size: int = 16, pretrained: bool = True):
        self.device = device
        self.batch_size = batch_size
        try:
            weights = models.ResNet18_Weights.DEFAULT if pretrained else None
            backbone = models.resnet18(weights=weights)
        except Exception:
            backbone = models.resnet18(weights=None)
        self.model = nn.Sequential(*list(backbone.children())[:-1], nn.Flatten()).to(device)
        self.model.eval()
        for p in self.model.parameters():
            p.requires_grad = False
        self.tf = transforms.Compose([
            transforms.Grayscale(num_output_channels=3),
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])

    def extract(self, paths: Sequence[Path]) -> np.ndarray:
        feats = []
        batch = []
        for p in paths:
            img = Image.open(p).convert("L")
            batch.append(self.tf(img))
            if len(batch) == self.batch_size:
                feats.append(self._forward(torch.stack(batch, dim=0)))
                batch = []
        if batch:
            feats.append(self._forward(torch.stack(batch, dim=0)))
        return np.vstack(feats) if feats else np.empty((0, 512), dtype=np.float32)

    def _forward(self, x: torch.Tensor) -> np.ndarray:
        with torch.no_grad():
            return self.model(x.to(self.device)).cpu().numpy()


def aggregate_patient_image_features(df_feat: pd.DataFrame, strategy: str = "meanmax") -> pd.DataFrame:
    feat_cols = [c for c in df_feat.columns if c.startswith("img_feat_")]
    rows = []
    for pid, sub in df_feat.groupby("ipatient"):
        arr = sub[feat_cols].to_numpy(dtype=np.float32)
        row = {"ipatient": str(pid), "n_images": int(len(sub))}
        if strategy in ("mean", "meanmax"):
            meanv = arr.mean(axis=0)
            for i, v in enumerate(meanv):
                row[f"img_mean_{i}"] = float(v)
        if strategy in ("max", "meanmax"):
            maxv = arr.max(axis=0)
            for i, v in enumerate(maxv):
                row[f"img_max_{i}"] = float(v)
        rows.append(row)
    return pd.DataFrame(rows)


def reduce_image_features(patient_img: pd.DataFrame, n_components: int = 3):
    img_cols = [c for c in patient_img.columns if c.startswith("img_mean_") or c.startswith("img_max_")]
    X = patient_img[img_cols].to_numpy(dtype=np.float32)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    n_components = min(n_components, Xs.shape[0] - 1, Xs.shape[1])
    if n_components < 1:
        raise ValueError("PCA components 無法設定，可能病人數太少。")
    pca = PCA(n_components=n_components, random_state=42)
    Z = pca.fit_transform(Xs)
    out = patient_img[["ipatient", "n_images"]].copy()
    for i in range(n_components):
        out[f"img_pc{i+1}"] = Z[:, i]
    var_info = {f"img_pc{i+1}": float(pca.explained_variance_ratio_[i]) for i in range(n_components)}
    return out, scaler, pca, var_info


def build_summary_table(cph_summary: pd.DataFrame) -> pd.DataFrame:
    out = cph_summary.copy().reset_index()
    feature_col = out.columns[0]
    out = out.rename(columns={feature_col: "feature"})
    keep_cols = [
        "feature", "coef", "exp(coef)", "se(coef)", "z", "p",
        "coef lower 95%", "coef upper 95%",
        "exp(coef) lower 95%", "exp(coef) upper 95%"
    ]
    keep_cols = [c for c in keep_cols if c in out.columns]
    return out[keep_cols].sort_values("p", ascending=True)


def prepare_survival_model_table(
    data_path: str | Path,
    time_sheet: str,
    feature_sheet: str,
    image_excel: str | Path,
    image_sheet: str,
    image_root: str | Path,
    output_dir: str | Path,
    img_size: int = 224,
    batch_size: int = 16,
    image_pooling: str = "meanmax",
    image_pca_components: int = 3,
    pretrained: bool = True,
    cpu: bool = False,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    data_path = Path(data_path)
    image_root = Path(image_root)

    df_time = safe_strip_columns(pd.read_excel(data_path, sheet_name=time_sheet))
    df_feat = safe_strip_columns(pd.read_excel(data_path, sheet_name=feature_sheet))

    id_col = find_first_existing_column(df_feat, ["ipatient", "patient_id", "ID"])
    time_id_col = find_first_existing_column(df_time, [id_col, "ipatient", "patient_id", "ID"])
    index_col = find_first_existing_column(df_time, ["Index Date", "index_date", "Index_Date"])
    end_col = find_first_existing_column(df_time, ["End point", "end_point", "End_Point", "censor_date", "end_date"])
    event_col = find_first_existing_column(df_feat, ["ORN_label", "event", "label"])
    if None in [id_col, time_id_col, index_col, end_col, event_col]:
        raise ValueError("時間表或 feature 表缺少必要欄位。")
    if event_col != "ORN_label":
        df_feat = df_feat.rename(columns={event_col: "ORN_label"})

    df_time_use = df_time[[time_id_col, index_col, end_col]].copy().rename(columns={
        time_id_col: id_col,
        index_col: "Index Date",
        end_col: "End point",
    })
    df = pd.merge(df_feat, df_time_use, on=id_col, how="inner")
    df["Index Date"] = pd.to_datetime(df["Index Date"], errors="coerce")
    df["End point"] = pd.to_datetime(df["End point"], errors="coerce")
    df["ORN_label"] = pd.to_numeric(df["ORN_label"], errors="coerce")
    df["time"] = (df["End point"] - df["Index Date"]).dt.days / 365.25
    df["event"] = df["ORN_label"]
    df = df.dropna(subset=["time", "event"]).copy()
    df = df[df["time"] >= 0].copy()
    df["event"] = df["event"].astype(int)
    df[id_col] = df[id_col].astype(str)

    image_df = safe_strip_columns(pd.read_excel(image_excel, sheet_name=image_sheet))
    if "ipatient" not in image_df.columns:
        raise ValueError("image sheet 缺少 ipatient。")
    image_df["ipatient"] = image_df["ipatient"].astype(str)
    image_df = image_df[image_df["ipatient"].isin(df[id_col])].copy().reset_index(drop=True)
    expanded_image_df = expand_rows_to_images(image_df, image_root, output_dir)
    if len(expanded_image_df) == 0:
        raise ValueError("找不到可用影像，請檢查 image_root 或 image_data.xlsx。")
    expanded_image_df.to_csv(output_dir / "expanded_image_table.csv", index=False, encoding="utf-8-sig")

    device = torch.device("cpu" if cpu or not torch.cuda.is_available() else "cuda")
    extractor = ImageFeatureExtractor(device=device, img_size=img_size, batch_size=batch_size, pretrained=pretrained)
    feats = extractor.extract([Path(p) for p in expanded_image_df["image_path"].tolist()])
    image_feat_df = expanded_image_df[["ipatient", "image_path", "resolved_filename"]].copy()
    for i in range(feats.shape[1]):
        image_feat_df[f"img_feat_{i}"] = feats[:, i]
    image_feat_df.to_csv(output_dir / "image_level_features.csv", index=False, encoding="utf-8-sig")

    patient_img = aggregate_patient_image_features(image_feat_df, strategy=image_pooling)
    patient_img_reduced, scaler, pca, var_info = reduce_image_features(patient_img, n_components=image_pca_components)
    patient_img_reduced.to_csv(output_dir / "patient_image_features_pca.csv", index=False, encoding="utf-8-sig")

    df_mm = pd.merge(df, patient_img_reduced, left_on=id_col, right_on="ipatient", how="inner")
    if "ipatient_y" in df_mm.columns:
        df_mm = df_mm.drop(columns=["ipatient_y"])
    if "ipatient_x" in df_mm.columns:
        df_mm = df_mm.rename(columns={"ipatient_x": id_col})

    candidate_features = [
        "mandible_resection_worst",
        "reconstruction_max",
        "tooth_extraction_count",
        "neck_dissection_pre_orn_any",
        "Tumor location",
        "年齡",
        "ECOG",
    ]
    selected_clinical = [c for c in candidate_features if c in df_mm.columns]
    image_pc_cols = [c for c in patient_img_reduced.columns if c.startswith("img_pc")]
    df_model = df_mm[[id_col, "time", "event"] + selected_clinical + image_pc_cols + ["n_images"]].copy()

    if "mandible_resection_worst" in df_model.columns:
        df_model["mandible_resection_worst"] = robust_map_mandible_worst(df_model["mandible_resection_worst"])
    if "reconstruction_max" in df_model.columns:
        df_model["reconstruction_max"] = robust_map_reconstruction_max(df_model["reconstruction_max"])
    for col in ["tooth_extraction_count", "neck_dissection_pre_orn_any", "年齡", "ECOG", "n_images"] + image_pc_cols:
        if col in df_model.columns:
            df_model[col] = pd.to_numeric(df_model[col], errors="coerce")
    for col in ["tooth_extraction_count", "年齡", "ECOG"]:
        if col in df_model.columns:
            df_model[col] = winsorize_series(df_model[col], 0.01, 0.99)
    if "Tumor location" in df_model.columns:
        df_model["Tumor location_grouped"] = group_tumor_location(df_model["Tumor location"])
        df_model = df_model.drop(columns=["Tumor location"])

    obj_cols = [c for c in df_model.select_dtypes(include=["object"]).columns if c != id_col]
    for col in obj_cols:
        df_model[col] = df_model[col].fillna("Unknown")
    num_cols = [c for c in df_model.select_dtypes(include=[np.number]).columns if c != "event"]
    for col in num_cols:
        if df_model[col].isna().all():
            df_model = df_model.drop(columns=[col])
        else:
            df_model[col] = df_model[col].fillna(df_model[col].median())
    if "Tumor location_grouped" in df_model.columns:
        dummies = pd.get_dummies(df_model["Tumor location_grouped"], prefix="Tumor location_grouped", drop_first=True)
        df_model = pd.concat([df_model.drop(columns=["Tumor location_grouped"]), dummies], axis=1)

    feature_cols = [c for c in df_model.columns if c not in [id_col, "time", "event"]]
    constant_cols = [c for c in feature_cols if df_model[c].nunique(dropna=True) <= 1]
    if constant_cols:
        df_model = df_model.drop(columns=constant_cols)
    meta = {
        "id_col": id_col,
        "n_original_image_rows": int(len(image_df)),
        "n_expanded_image_rows": int(len(expanded_image_df)),
        "n_patients_with_images": int(expanded_image_df["ipatient"].nunique()),
        "image_pooling": image_pooling,
        "image_pca_components": len(image_pc_cols),
        "image_pca_explained_variance_ratio": var_info,
        "device_used": str(device),
    }
    return df_model, meta


def train_survival_bundle(
    data_path: str | Path = "data_v3.1.xlsx",
    time_sheet: str = "ALL",
    feature_sheet: str = "model_full_pre_orn",
    image_excel: str | Path = "image_data.xlsx",
    image_sheet: str = "image_master",
    image_root: str | Path = "images",
    output_dir: str | Path = "survival_bundle_outputs",
    output_path: str | Path = "survival_model_bundle.joblib",
    img_size: int = 224,
    batch_size: int = 16,
    image_pooling: str = "meanmax",
    image_pca_components: int = 3,
    pretrained: bool = True,
    cpu: bool = False,
) -> Dict[str, Any]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    df_model, meta = prepare_survival_model_table(
        data_path=data_path,
        time_sheet=time_sheet,
        feature_sheet=feature_sheet,
        image_excel=image_excel,
        image_sheet=image_sheet,
        image_root=image_root,
        output_dir=output_dir,
        img_size=img_size,
        batch_size=batch_size,
        image_pooling=image_pooling,
        image_pca_components=image_pca_components,
        pretrained=pretrained,
        cpu=cpu,
    )
    id_col = meta["id_col"]
    feature_cols = [c for c in df_model.columns if c not in [id_col, "time", "event"]]
    clinical_only_cols = [c for c in feature_cols if not c.startswith("img_pc")]
    multimodal_cols = feature_cols.copy()

    cph_clin = None
    clinical_cindex = float("nan")
    if clinical_only_cols:
        df_clin = df_model[["time", "event"] + clinical_only_cols].copy()
        cph_clin = CoxPHFitter(penalizer=0.20, l1_ratio=0.0)
        cph_clin.fit(df_clin, duration_col="time", event_col="event")
        clinical_cindex = float(cph_clin.concordance_index_)

    df_multi = df_model[["time", "event"] + multimodal_cols].copy()
    cph_multi = CoxPHFitter(penalizer=0.20, l1_ratio=0.0)
    cph_multi.fit(df_multi, duration_col="time", event_col="event")
    multimodal_cindex = float(cph_multi.concordance_index_)

    df_out = df_model[[id_col, "time", "event"]].copy()
    df_out["risk_score"] = cph_multi.predict_partial_hazard(df_multi).values
    median_risk = float(df_out["risk_score"].median())
    df_out["risk_group"] = np.where(df_out["risk_score"] >= median_risk, "High", "Low")

    logrank_p = float("nan")
    try:
        low = df_out["risk_group"] == "Low"
        high = df_out["risk_group"] == "High"
        lr = logrank_test(
            df_out.loc[low, "time"],
            df_out.loc[high, "time"],
            event_observed_A=df_out.loc[low, "event"],
            event_observed_B=df_out.loc[high, "event"],
        )
        logrank_p = float(lr.p_value)
    except Exception:
        pass

    cox_summary = build_summary_table(cph_multi.summary)
    cox_summary.to_csv(output_dir / "cox_multimodal.csv", index=False, encoding="utf-8-sig")
    df_out.to_csv(output_dir / "patient_risk_scores_multimodal.csv", index=False, encoding="utf-8-sig")

    bundle: Dict[str, Any] = {
        "bundle_type": "multimodal_survival_cox",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "source_pipeline": "orn_multimodal_survival.py compatible deploy bundle",
        "model_name": "Multimodal Cox proportional hazards model",
        "cox_model": cph_multi,
        "clinical_only_cindex": clinical_cindex,
        "multimodal_cindex": multimodal_cindex,
        "cindex_improvement": float(multimodal_cindex - clinical_cindex) if not np.isnan(clinical_cindex) else float("nan"),
        "logrank_p": logrank_p,
        "feature_columns": multimodal_cols,
        "df_model": df_model,
        "patient_risk_table": df_out,
        "risk_score_thresholds": {"high_vs_low_median": median_risk},
        "cox_summary": cox_summary,
        "metadata": meta,
        "notes": [
            "Cox partial hazard is a relative risk score, not an absolute probability.",
            "LLM should not describe risk_score as percentage unless an absolute-risk conversion is explicitly added.",
        ],
    }
    joblib.dump(bundle, output_path)
    return bundle


def load_bundle(path: str | Path) -> Dict[str, Any]:
    return joblib.load(path)


def _json_safe(x: Any) -> Any:
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        val = float(x)
        return None if np.isnan(val) or np.isinf(val) else val
    if isinstance(x, (pd.Timestamp,)):
        return x.isoformat()
    if isinstance(x, bool):
        return bool(x)
    return x


def case_json_from_survival_patient(bundle: Dict[str, Any], patient_id: str) -> Dict[str, Any]:
    risk_df = bundle["patient_risk_table"].copy()
    id_col = bundle.get("metadata", {}).get("id_col", ID_COL)
    risk_df[id_col] = risk_df[id_col].astype(str)
    sub = risk_df[risk_df[id_col] == str(patient_id)]
    if sub.empty:
        raise ValueError(f"找不到 patient_id={patient_id}")
    r = sub.iloc[0]
    df_model = bundle["df_model"].copy()
    df_model[id_col] = df_model[id_col].astype(str)
    row = df_model[df_model[id_col] == str(patient_id)].iloc[0]

    cox_summary = bundle.get("cox_summary", pd.DataFrame()).copy()
    factors: List[Dict[str, Any]] = []
    if not cox_summary.empty:
        for _, s in cox_summary.iterrows():
            feat = s.get("feature")
            if feat not in bundle["feature_columns"]:
                continue
            hr = float(s.get("exp(coef)", np.nan))
            direction = "increase_risk" if hr >= 1 else "decrease_risk"
            factors.append({
                "feature": feat,
                "display_name": FEATURE_DISPLAY.get(str(feat), str(feat)),
                "value": _json_safe(row.get(feat)),
                "hazard_ratio": hr,
                "ci_95": [
                    _json_safe(s.get("exp(coef) lower 95%")),
                    _json_safe(s.get("exp(coef) upper 95%")),
                ],
                "p_value": _json_safe(s.get("p")),
                "direction": direction,
                "plain_language": PLAIN_LANGUAGE.get(str(feat), "此變項在 Cox 模型中與相對風險有關，需搭配信賴區間與臨床背景判讀。"),
            })
    positive = [f for f in factors if f["direction"] == "increase_risk"][:6]
    negative = [f for f in factors if f["direction"] == "decrease_risk"][:6]

    return {
        "schema_version": "1.1",
        "case_type": "multimodal_survival_cox",
        "patient": {
            "patient_id": str(patient_id),
            "time_years": float(r["time"]),
            "event": int(r["event"]),
            "available_features": {c: _json_safe(row[c]) for c in bundle["feature_columns"] if c in row.index},
        },
        "prediction": {
            "model_type": "cox_survival",
            "model_name": bundle.get("model_name", "Multimodal Cox model"),
            "target_event": "time to ORN event or censoring",
            "risk_score": float(r["risk_score"]),
            "risk_group": str(r["risk_group"]),
            "thresholds": bundle.get("risk_score_thresholds", {}),
            "interpretation_note": "此 risk_score 為 Cox partial hazard 相對風險分數，不是 ORN 發生機率百分比。",
        },
        "model_performance": {
            "clinical_only_cindex": bundle.get("clinical_only_cindex"),
            "multimodal_cindex": bundle.get("multimodal_cindex"),
            "cindex_improvement": bundle.get("cindex_improvement"),
            "logrank_p_high_vs_low": bundle.get("logrank_p"),
            **bundle.get("metadata", {}),
        },
        "explanation": {
            "method": "Cox hazard ratio summary plus patient feature values",
            "top_positive_factors": positive,
            "top_negative_factors": negative,
            "missing_or_uncertain_items": [
                "Cox risk_score is relative. Do not present it as absolute probability unless baseline survival is added."
            ],
        },
        "llm_guardrails": {
            "allowed_tasks": [
                "Explain relative risk score and risk group.",
                "Summarize Cox HR factors and image PCs.",
                "State limitations clearly."
            ],
            "forbidden_tasks": [
                "Do not describe risk_score as a percentage probability.",
                "Do not diagnose ORN.",
                "Do not provide treatment instructions.",
                "Do not invent radiological findings from img_pc features."
            ],
            "required_disclaimer": "本系統為 ORN 生存風險分層輔助工具，Cox risk score 為相對風險，不取代臨床診斷或醫師判讀。",
        },
    }
