# ORN 個人化風險分層與 LLM 輔助解釋介面

這份壓縮檔已依照你目前三個真實 pipeline 重新整理：

1. `pipeline_final_beeswarm.py` → 臨床結構化資料分類模型 bundle
2. `orn_multimodal_survival.py` → 臨床 + panoramic X-ray image PCA 的 Cox 生存風險模型 bundle
3. `orn_image_baseline_pipeline_v7_compare.py` → 影像模型結果表讀取與 JSON 解釋

重點設計原則：

- 模型負責計算風險。
- JSON 負責固定模型輸出與解釋欄位。
- Gemma 4 / 對話框只根據 JSON 解釋，不重新計算、不修改分數、不診斷 ORN。
- Cox survival model 的 `risk_score` 是相對風險，不是百分比機率。

---

## 檔案結構

```text
orn_risk_ui_true_pipelines/
├── app.py
├── requirements.txt
├── README.md
│
├── clinical_backend.py
├── train_clinical_bundle.py
├── predict_clinical_json.py
│
├── survival_backend.py
├── train_survival_bundle.py
├── predict_survival_json.py
│
├── image_results_backend.py
├── predict_image_json.py
│
├── sample_json/
│   ├── clinical_case_example.json
│   ├── survival_case_example.json
│   └── image_case_example.json
│
└── source_pipelines/
    ├── pipeline_final_beeswarm.py
    ├── orn_multimodal_survival.py
    └── orn_image_baseline_pipeline_v7_compare.py
```

---

## Colab 執行方式

### 1. 上傳並解壓縮

```python
from google.colab import files
uploaded = files.upload()
```

選擇：

```text
orn_risk_ui_true_pipelines.zip
```

```python
import zipfile, os, glob
zip_path = "orn_risk_ui_true_pipelines.zip"
with zipfile.ZipFile(zip_path, "r") as z:
    z.extractall("/content")
os.chdir("/content/orn_risk_ui_true_pipelines")
!ls -la
```

### 2. 安裝套件

```python
!pip install -q -r requirements.txt
```

### 3. 先開啟範例介面

```python
!pkill -f streamlit || true
!streamlit run app.py \
  --server.port 8501 \
  --server.address 127.0.0.1 \
  --server.headless true \
  --server.enableCORS false \
  --server.enableXsrfProtection false \
  > /content/streamlit.log 2>&1 &
```

```python
!wget -q -O cloudflared https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64
!chmod +x cloudflared
!./cloudflared tunnel --url http://127.0.0.1:8501
```

打開 Cloudflare 產生的網址。

---

## 模式 A：臨床分類模型 bundle

來源邏輯：`pipeline_final_beeswarm.py`

輸出：

- `predicted_probability`
- Low / Intermediate / High risk group
- local feature replacement explanation
- ROC-AUC / Brier / ECE / sensitivity / specificity

訓練：

```bash
python train_clinical_bundle.py \
  --data_path data_v3.1.xlsx \
  --sheet_name model_full_pre_orn \
  --output_path clinical_model_bundle.joblib \
  --min_sensitivity 0.80
```

輸出單一病人 JSON：

```bash
python predict_clinical_json.py \
  --bundle_path clinical_model_bundle.joblib \
  --patient_id P001 \
  --output_json clinical_case_real.json
```

然後重新啟動 `app.py`，左側選「臨床分類模型 bundle」。

---

## 模式 B：多模態 Cox 生存模型 bundle

來源邏輯：`orn_multimodal_survival.py`

輸出：

- `risk_score`
- High / Low risk group
- clinical-only C-index
- multimodal C-index
- log-rank p-value
- Cox HR 解釋
- image PCA features: `img_pc1`, `img_pc2`, `img_pc3`

注意：`risk_score` 是 Cox partial hazard 相對風險，不是 ORN 發生機率百分比。

訓練：

```bash
python train_survival_bundle.py \
  --data_path data_v3.1.xlsx \
  --time_sheet ALL \
  --feature_sheet model_full_pre_orn \
  --image_excel image_data.xlsx \
  --image_sheet image_master \
  --image_root /content/your_image_folder \
  --output_path survival_model_bundle.joblib \
  --output_dir survival_bundle_outputs
```

若 Colab 無法下載 torchvision pretrained weights，可加：

```bash
--no_pretrained
```

輸出單一病人 JSON：

```bash
python predict_survival_json.py \
  --bundle_path survival_model_bundle.joblib \
  --patient_id P001 \
  --output_json survival_case_real.json
```

---

## 模式 C：影像 pipeline 結果檢視

來源邏輯：`orn_image_baseline_pipeline_v7_compare.py`

這一模式目前不是重新做影像推論，而是讀取影像 pipeline 已輸出的：

```text
cv_patient_level_predictions_all_folds.csv
cv_metrics_summary.json
```

輸出單一病人 JSON：

```bash
python predict_image_json.py \
  --prediction_table cv_patient_level_predictions_all_folds.csv \
  --metrics_summary cv_metrics_summary.json \
  --patient_id P001 \
  --output_json image_case_real.json
```

或是在 `app.py` 左側選「影像 pipeline 結果檢視」直接上傳 CSV / JSON。

---

## 論文寫法建議

可寫成：

> 本研究建置一套個人化 ORN 風險分層與 LLM 輔助解釋介面。系統先由分類模型或 Cox 生存模型輸出結構化 JSON，包括風險分數、分層門檻、模型效能與主要解釋因子；LLM 僅根據此 JSON 產生臨床可讀說明，不參與風險計算，也不允許改寫模型分數或產生診斷結論。

---

## Gemma 4 API 設定

本版介面支援 Google Gemini API hosted Gemma 4 models：

- `gemma-4-26b-a4b-it`
- `gemma-4-31b-it`

Colab 可用環境變數提供 API key：

```python
import os
os.environ["GEMINI_API_KEY"] = "你的 API key"
# 或
os.environ["GOOGLE_API_KEY"] = "你的 API key"
```

介面左側選擇：

```text
LLM 模式 → Gemma 4 API
Gemma 4 model → gemma-4-26b-a4b-it 或 gemma-4-31b-it
```

需勾選同意傳送目前案例 JSON。若 API key 未提供、未勾選同意，或 API 呼叫失敗，系統會自動回到 Rule-based fallback。

## LLM 驗證指標

Gemma 4 產生每段回覆後，介面會以與模型指標相同大小的 metric card 顯示：

- BERTScore F1
- BERTScore Precision
- BERTScore Recall
- 禁用語句檢查
- 分數一致性
- 風險分層提及

注意：BERTScore 只代表生成說明與參考說明的語意相似度，不能保證臨床正確性，也不能完全防止幻覺。

## 防止 LLM 幻覺的設計

JSON 中包含：

```text
prediction
model_performance
explanation
llm_guardrails
```

LLM 只能回答：

- 為什麼是高風險
- 哪些因素提高或降低風險
- 影像特徵代表什麼
- 模型限制

LLM 不可以：

- 重算風險分數
- 修改 probability / risk_score
- 診斷病人已經有 ORN
- 給治療建議
- 從 img_pc 自行推論具體影像病灶

## v4 更新

- 影像 pipeline 結果檢視：完整展開 `cv_metrics_summary.json` 中的 nested metrics，例如 patient-level / image-level AUROC、F1、sensitivity、specificity。
- 影像 pipeline 結果檢視：新增「查看此病人的影像 prediction row 數值」，可直接看到 `prob`、`threshold`、`pred_patient`、`y_true` 等欄位。
- LLM 輔助解釋對話：每次產生回答後會顯示 BERTScore Precision / Recall / F1。
- 若未安裝或無法載入 `bert-score` / `bert-base-chinese`，介面會顯示 fallback text-overlap 分數，並明確標註該值不是正式 BERTScore。正式論文或報告建議安裝 `bert-score` 後重新計算。

---

## v5：Gemini API 版本

本版新增真正的 Gemini API 介接，按鈕不再只使用固定模板。每個功能按鈕會產生不同 prompt，再由 Gemini 根據目前案例 JSON 生成受控式解釋。

### 新增功能

- 左側新增「LLM 介接設定」
  - Rule-based fallback
  - Gemini API
- 可輸入 Gemini API key，或從環境變數讀取：
  - `GOOGLE_API_KEY`
  - `GEMINI_API_KEY`
- 每個按鈕對應不同 prompt：
  - 說明分層門檻
  - 解釋主要風險
  - 列出降低風險因子
  - 影像資訊怎麼看
  - 產生醫師摘要
- Gemini 回覆後仍會顯示：
  - BERTScore Precision / Recall / F1
  - LLM mode
  - model name
  - 禁用語句檢查
  - 分數一致性檢查

### Colab 設定 Gemini API key

方式 A：直接在 Streamlit 左側輸入 API key。

方式 B：在 Colab 設定環境變數，較適合展示：

```python
import os
os.environ["GEMINI_API_KEY"] = "你的_Gemini_API_Key"
```

重新啟動 Streamlit 後，左側選擇「Gemini API」，並勾選同意傳送目前案例 JSON。

### 注意事項

Gemini API 會接收目前案例 JSON 內容。正式展示時請確認資料已去識別化，不要放入姓名、身分證字號、電話、地址或其他可識別個資。

若 Gemini API 呼叫失敗、未輸入 key、未勾選同意，系統會自動退回 Rule-based fallback，確保介面仍可運作。

## v7：Gemma 4 按鈕無回覆修正

本版針對 Gemma 4 模式下按鈕看似沒有反應的問題進行修正：

- Gemma 4 改用 Gemini API REST endpoint 呼叫，並加入明確 timeout。
- 左側新增「API timeout 秒數」設定，預設 35 秒。
- 按下快速功能按鈕或輸入問題時，介面會顯示 spinner：
  - 正在呼叫 Gemma 4 產生說明
  - 正在計算 LLM 驗證指標
- 若 Gemma 4 API key 錯誤、未授權、模型不可用或逾時，系統會自動回到 rule-based fallback，並在 LLM 驗證指標下方顯示 fallback reason。
- API key 仍可使用 `GEMINI_API_KEY` 或 `GOOGLE_API_KEY` 環境變數，也可在左側欄位輸入。

